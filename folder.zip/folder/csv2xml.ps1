# csv2xml
#
# Simple modul to convert a CSV-Style Input to a pretty XML-File
#
# 20150403 frank.carius@netatwork.de  Initial Version with parameter for files
# 20171108 frank.carius@netatwork.de  Change to Pipeline Processing
# 20171109 frank.carius@netatwork.de  Add Escaping for five special characters

[CmdletBinding()]
param (
	[parameter(ValueFromPipeline=$True)]
	[string]$line
)

begin{
	write-verbose "CSV2XML:Start"
	"<?xml version=`"1.0`" encoding=`"ISO-8859-15`"?>" 
	"<!-- XML File generated with CSV2XML -->" 
	"<csv2xml>" 
	[long]$count=0
}

process{
	$count++
	if ($count%100 -eq 0 ) {
		write-verbose "Line $count"
	}
	"  <line>" 
	foreach ($property in ($_ | gm -MemberType noteproperty)) {
		[string]$value = $_.($property.name)
		$value = $value.replace("""","&quot;")
		$value = $value.replace("'","&apos;")
		$value = $value.replace("<","&lt;")
		$value = $value.replace(">","&gt;")
		$value = $value.replace("&","&amp;")
		("    <"+$property.name+">"+ $value+"</"+$property.name+">") 
	}
	"  </line>" 
}
end {
	"</csv2xml>" 
	write-verbose "CSV2XML:End"
}
