<# 
 .Synopsis
  Offers an easy wa to add tracing to console and files to powershell scripts

 .Description
  Load as module and use Set-TraceParameter, Get-TraceParameter and Write-trace to use the module
  write-output, write-verbose and start-transcript are slowing down large scripts and should be uses for screen interactivity
  write-trace adds a commandlet to send any kind og details to a file or the console in a formatted ways

# 20171019 frank@carius.de  initial version
# 20171107 frank@carius.de  use leading spaces for DBG level deepness
# 20171107 frank@carius.de  Set Default Levels from 3 to 8

  
 .Parameter noparameter
  No Parameters for the module are available


 .Example
	Import module, set some parameters and keywords and do some output
	import-module .\write-trace.psm1 -force
	set-TraceParameter -filename ".\testrace.log"
	set-TraceParameter -filterkeywords "Wort1 wort2 word32"
	get-TraceParameter | fl
	write-trace "Normal"
	write-trace -level 1 -keyword "wort1" "Error"
	write-trace -level 2 -keyword "wort1" "Warning"

#>

write-host "Write-Trace Module loading"

# this variabels are local for the module and not exposed to the importing script
[string]$tracefilename = ""
[int]$tracelevelfile=8
[int]$tracelevelcon=8
[string]$tracefilterkeywords=" "

function Set-TraceParameter {
	# Configure parameters of the trace writer
	param (
		[string]$tracefilename,
		[int]$levelfile,
		[int]$levelcon,
		[string]$filterkeywords
	)
	if ($tracefilename)  {
		write-verbose "Update Trace Parameter  tracefilename with $($tracefilename)"
		$script:tracefilename=$tracefilename
	}
	if ($levelfile) {
		$script:tracelevelfile=$levelfile
		write-verbose "Update Trace Parameter  tracelevelfile with $($levelfile)"
	}
	if ($levelcon)  {
		$script:tracelevelcon=$levelcon
		write-verbose "Update Trace Parameter  tracelevelcon with $($levelcon)"
	}
	if ($filterkeywords)  {
		$script:tracefilterkeywords= " " +$filterkeywords
		write-verbose "Update Trace Parameter  $filterkeywords with $($filterkeywords)"
	}
}

function Get-TraceParameter {
	# return the current parameter of the trace writer
	New-Object PSObject -Property @{
		tracefilename = $script:tracefilename
		tracelevelfile=$script:tracelevelfile
		tracelevelcon=$script:tracelevelcon
		filterkeywords=$script:tracefilterkeywords
	}
}

function Write-Trace {
	# Write message to the target

    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)][ValidateNotNullOrEmpty()]
			[string]$Message,   # message to wrinte
        [Parameter(Mandatory=$false)]
			[int]$Level=0,       # level of the specific message  0=info, 1=error, 2=warning  3.. = debuglevel
		[Parameter(Mandatory=$false)]
			[string]$keyword     # Keyword or section of the trace for filtering
    )

	Begin { 
	}
	Process {
		# Write message to error, warning, or verbose pipeline and specify $LevelText
		if (($tracefilterkeywords -eq " ") -or ($tracefilterkeywords.contains($keyword))) {
			# tracefilterkeywords
			
			if (($level -le $script:tracelevelfile) -or (($level -le $script:tracelevelcon))) {
				$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				switch ($Level) {
					0 		{$Message = "$($timestamp) LOG0  :$($keyword):$($Message)"}
					1 		{$Message = "$($timestamp) ERR1  :$($keyword):$($Message)" ; Write-Error  $Message}
					2 		{$Message = "$($timestamp) WRN2 :$($keyword):$($Message)" ; Write-Warning $Message}
					3 		{$Message = "$($timestamp) INF3 :$($keyword):$($Message)" ; Write-Verbose $Message}
					default {$Message = "$($timestamp) DBG$($Level) :$($keyword):$(".."*($Level-2))$($Message)"}
				}
				if ($script:tracefilename) {
					# send trace to file
					$Message | Out-File -FilePath $script:tracefilename -Append
				}
				if ($level -le $script:tracelevelcon) {
					# send trace to console
					write-host $Message 
				}
			}
		}
    }
	End {
	}
}
write-host "Write-Trace Module loaded"
