#Export-Rules
#
# Exportiert Regeln eines Postfachs in eine CSV-Datei


param (
	$mailbox = "decar",
	$csvfile = ".\rules.csv",
	$xmlfile = ".\rules.xml"
)

set-psdebug -strict

$error.clear()

if (!(get-command get-inboxrule -erroraction silentlycontinue)) {
	write-warning " Commandlet not found. Please use Exchange Powershell"
	exit
}
else {
	get-inboxrule `
	| convertto-xml `
	| out-file -filepath $xmlfile

	get-inboxrule `
	| export-csv -notypeinformation -path $csvfile

}