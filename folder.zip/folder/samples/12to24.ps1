$filelist = get-childitem "C:\Tasks\NEXTCCCReporting\trackingcsv\done12\*.csv"
foreach ($csvfile in $filelist){
	write-host "Reading $($csvfile.fullname)"
	$hour24 = [int]($csvfile.name[33..34] -join "")
	if ($hour24 -eq 00) {
		write-host " Processing 00 Uhr"
		import-csv $csvfile.fullname `
		| %{$_timestamp = ([datetime]$_.Timestamp).addhours(-12).tostring( "yyyy-MM-dd HH:mm:ss.fff")} `
		| export-csv $("C:\Tasks\NEXTCCCReporting\trackingcsv\done24\" + $csvfile.name ) -encoding unicode -notypeinformation
	}
	if ($hour24 -gt 13) {
		write-host " Processing 13-23 Uhr"
		import-csv $csvfile.fullname `
		| %{$_timestamp = ([datetime]$_.Timestamp).addhours(12).tostring( "yyyy-MM-dd HH:mm:ss.fff")} `
		| export-csv $("C:\Tasks\NEXTCCCReporting\trackingcsv\done24\" + $csvfile.name ) -encoding unicode -notypeinformation
	}
	else {
		write-host " Processing 01-12 Uhr"
		import-csv $csvfile.fullname `
		| export-csv $("C:\Tasks\NEXTCCCReporting\trackingcsv\done24\" + $csvfile.name ) -encoding unicode -notypeinformation
	}
}

