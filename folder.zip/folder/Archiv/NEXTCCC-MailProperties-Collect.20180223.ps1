﻿# NEXTCCC-MailProperties-Collect.ps1
#
# 20171026 JGD Initial Version
# 20171107  FC
#	Erweiterung um Autodiscover Adresse mit alternativem Einlesen.
#	Write-Trace Ausgaben
#	InternetmessageID addiert
#	Typisierung von Variablen
#	Errorbehandlung Autodiscover
#	Searchfilter auf letzte 24 Stunden
# 20171108 FC
#	MessageSubject entfernt
#	Disable 24h Filter
# 20171108 FC
#	Add $timeformat" for DateTie Formatting
# Requires Installed Managed EWS API dll
# 20171122 FC
#	DateTime in 24h format
#	FlagStartDateTime Behandlung 0001-01-01 12:00:00.000
# 20171127 JGD
#	changed JobID to match DateTime
# 20171207 FC
#	FlagStartDateTime Behandlung 0001-01-01 00:00:00.000
# 20180115 JGD 1.1
#	Added $global:mailCount to count processed mails for each mailbox and writing result in trace
#	Fixed string at the end to end instead of start
# 20180115 JGD 1.2
#	Fixed Issue with FolderId being to long if a space has been found in the name, maximum characters is always 5
#	Fixed issue with wrong mailcount handling
# 20180214 FC
#	AutoD Adresse ersetzt durch Get-Recipient
# 20180222 JGD
#	Added Flag $ignoreOutOfScopeMails which do not collect mails not with FolderID xx oder xx_yy if set to $true
# 201180223 JGD
#	Added flag $earliestReceivedDateTime. Only mails newer than this datetime are written to the database
# Optionen
#	Parallelisierung der Abfragen
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),
	[string]$configcsv        = "C:\Tasks\NEXTCCCReporting\NEXTCCC-Mailboxlist.config.csv",
    [string]$ewsDllLoc        = "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll",
	[string]$exportcsvfile    = "",
	#$starttimestamp =(get-date (get-date).addhours(-1) -format "MM/dd/yyyy HH:00:00"),   # start of this day
	#$endtimestamp = (get-date -format "MM/dd/yyyy HH:00:00"),   # 
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff",
	$ignoreOutOfScopeMails    = $true, #if set to true, only mails with FolderID xx and xx_yy are collected
	$earliestReceivedDateTime = "2018-01-01 00:00:00.001", # only take into account the mails, which are received after this date
	[string]$test=""     # Set to true to check Control-M Logic
)

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')
[int]$global:mailCount = 0
##########################################################
# Helper Function to do tracing
##########################################################

Import-Module .\write-trace.psm1
set-TraceParameter `
   -tracefilename ".\logs\NEXTCCC-MailProperties-Collect.trace.$($jobidlog).log" `
   -levelfile 5 `
   -levelcon 5


Write-Trace "Collect-Mailproperties: Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "configcsv               : $($configcsv)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"

if ($exportcsvfile -eq "") {
   Write-Trace "Parameter exportcsvfile is not set"
   $exportcsvfile = ".\ewscsv\NEXTCCC-MailProperties-Collect.$($jobidlog).csv"
}
Write-Trace "Parameter exportcsvfile : $exportcsvfile"

##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#$objectRef = $host.GetType().GetField(“externalHostRef”, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetProperty”
#$consoleHost = $objectRef.GetType().GetProperty(“Value”, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(“IsStandardOutputRedirected”, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#  $field = $consoleHost.GetType().GetField(“standardOutputWriter”, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(“standardErrorWriter”, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path ".\logs")) {mkdir ".\logs"}
[string]$transcriptfile = (".\logs\NEXTCCC-MailProperties-Collect.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace " Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Cleanup old Logfiles"
[string[]]$oldlogfilelist=""
get-item -path ".\logs\NEXTCCC-MailProperties-Collect.*.log" `
	| where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
	| %{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  Logfile $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old LogFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old LogFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old LogFile: $($oldlogfile)"
	}
}  

Write-Trace " Cleanup old Logfiles"
[string[]]$oldlogfilelist=""
get-item -path ".\ewscsv\done\*.csv" `
	| where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
	| %{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  CSVFile  $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old CSVFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old CSVFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old CSVFile: $($oldlogfile)"
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-MailProperties-Collect:Start"
$starttime = get-date

##########################################################
# Define Functions for processing folders/mails 
##########################################################
function ConvertToString($ipInputString){
    $Val1Text = ""
    for ($clInt=0;$clInt -lt $ipInputString.length;$clInt++){  
		$Val1Text = $Val1Text + [Convert]::ToString([Convert]::ToChar([Convert]::ToInt32($ipInputString.Substring($clInt,2),16)))  
		$clInt++  
	}  
	return $Val1Text  
}  

# 
# Bind EWS to given Mailbox and start from Inbox
#
function Process-Mailbox{
	param (
		[string]$mailAddress   # SMTP_Adresse des Postfachs
	)
	Write-Trace "Process-Mailbox: Start"
	$global:mailCount = 0
	Write-Trace " Initializing EWS"
    $ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
    ## Create Exchange Service Object
    $service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
        
    $service.UseDefaultCredentials = $true
	$service.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$mailAddress ); 

	Write-Trace " Try Autodiscover for $($mailAddress)"
	try {
		#$service.TraceEnabled = $true
		$service.AutodiscoverUrl($mailAddress,{$true})
		#$service.TraceEnabled = $false
	}
	catch {
		write-warning " Unable to get Autodiscover entry"
	}
	$error.clear()
	if ($service.Url -ne $null){
		Write-Trace "  Prepare Folder Search"
			
		#"Checking : " + $mailAddress  
		#Define Extended propserties  
		$PR_FOLDER_TYPE = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(13825,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);  
		$folderidcnt = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox) 
		
		
		# Compile PropertySet of Folders to load
		$psPropertySet = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
		$PR_MESSAGE_SIZE_EXTENDED = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(3592,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Long); 
		#$PR_DELETED_MESSAGE_SIZE_EXTENDED = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(26267,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Long);  
		$PR_Folder_Path = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(26293, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::String);  
		#Add Properties to the  Property Set  
		$psPropertySet.Add($PR_MESSAGE_SIZE_EXTENDED); 
		$psPropertySet.Add($PR_Folder_Path);  

		#Define the FolderView used for Export should not be any larger then 1000 folders due to throttling  
		$fvFolderView =  New-Object Microsoft.Exchange.WebServices.Data.FolderView(1000)  
		#Deep Transval will ensure all folders in the search path are returned  
		$fvFolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep;  
		$fvFolderView.PropertySet = $psPropertySet; 
		
		#The Search filter will exclude any Search Folders  
		$sfSearchFilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo($PR_FOLDER_TYPE,"1")  
		$fiResult = $null  
		
		$Inbox = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$folderidcnt)  

		Write-Trace "Process-Mailbox:  Search Folders" 7
		$fiResult = $service.FindFolders($folderidcnt,$sfSearchFilter,$fvFolderView)  

		Write-Progress `
			-Id 2 `
			-ParentId 1 `
			-Activity "Mailfoldercount 1 of $($fiResult.TotalCount +1)" `
			-Status "Mailfolder Inbox" `
			-PercentComplete (1 / ($fiResult.TotalCount + 1) *100)

		Process-Folder $Inbox $mailAddress $true #isInbox
		
		$folderCount = 1;
		#The Do loop will handle any paging that is required if there are more the 1000 folders in a mailbox  
		do {  
			$fiResult = $service.FindFolders($folderidcnt,$sfSearchFilter,$fvFolderView)  
			foreach($ffFolder in $fiResult.Folders){  
				$folderCount++
				$perc = $folderCount / ($fiResult.TotalCount + 1) *100
				if($perc -gt 100){
					$perc = 100
				}
				Write-Progress `
						-Id 2 `
						-ParentId 1 `
						-Activity "Mailfoldercount $($folderCount) of $($fiResult.TotalCount +1)" `
						-Status "Mailfolder $fpath" `
						-PercentComplete ($perc)
					
				Process-Folder $ffFolder $mailAddress $false #notInbox
			} 
			$fvFolderView.Offset += $fiResult.Folders.Count 
		}
		while($fiResult.MoreAvailable -eq $true)  
	}			
	Write-Trace "Process-Mailbox: Processed mails: $($global:mailCount)"
	Write-Trace "Process-Mailbox: End"
}

function Process-Folder {
	param ( 
		$folderItem, 
		[string]$mailAddress, 
		[boolean]$isInbox   # true for special handling of Inbox folder
	)
	
	Write-Trace "Process-Folder: Start" 8
	Write-Trace "  FolderDisplayName : $($FolderItem.displayName)" 8
	Write-Trace "  TotalItemCount    : $($folderItem.TotalCount)"  8
	if(!$isInbox){
		$FolderSize = $null;  
		$FolderSizeValue = 0  
		#Try to Get the FolderSize Value and output it to the $FolderSize varible  
		if ($folderItem.TryGetProperty($PR_MESSAGE_SIZE_EXTENDED,[ref] $FolderSize))  
		{  
			$FolderSizeValue = [Int64]$FolderSize  
		}  
		$foldpathval = $null  
		#Try to get the FolderPath Value and then covert it to a usable String   
		if ($folderItem.TryGetProperty($PR_Folder_Path,[ref] $foldpathval))  
		{  
			$binarry = [Text.Encoding]::UTF8.GetBytes($foldpathval)  
			$hexArr = $binarry | ForEach-Object { $_.ToString("X2") }  
			$hexString = $hexArr -join ''  
			$hexString = $hexString.Replace("FEFF", "5C00")  
			$fpath = ConvertToString($hexString)  
		}  
		 
		Process-MailsInFolder $folderItem $fpath $mailAddress
	}
	else
	{
		$fpath = "Inbox"
		Process-MailsInFolder $folderItem $fpath $mailAddress
	}
	Write-Trace "Process-Folder: End" 8
}

function Process-MailsInFolder{
	param (
		$folderItem, 
		[string]$fpath, 
		[string]$mailAddress
	)
	
	Write-Trace "Process-MailsInFolder: Start" 9
	[long]$pageSize = 5
	[long]$offset = 0

	#$PidTagSubject = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x0037,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::String)
	$PidTagFlagStatus = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x1090, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer)
	$PidTagFlagCompleteTime = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x1091, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
	$propertySet = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
	#$propertySet.Add($PidTagSubject)
	$propertySet.Add($PidTagFlagStatus)
	$propertySet.Add($PidTagFlagCompleteTime)
	$ivItemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView(($pageSize+1),$offset)
	$ivItemView.Traversal = [Microsoft.Exchange.WebServices.Data.ItemTraversal]::Shallow
	$ivItemView.PropertySet = $propertySet
	#view.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Descending);
	
	#$ivsearchfilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsGreaterThan([Microsoft.Exchange.WebServices.Data.ItemSchema]::LastModifiedTime,[system.DateTime]::Now.AddDays(-1))
	[long]$i = 0

	do {
		$findItemsResults = $folderItem.FindItems($ivItemView)
		#$findItemsResults = $folderItem.FindItems($ivsearchfilter,$ivItemView)   # enable Search by date
		
		foreach($miMailItems in $findItemsResults.Items) {
			$i++   
			$perc = $i / $findItemsResults.TotalCount *100
			if ($perc -gt 100) {
				$perc = 100
			}
			Write-Progress `
				-ParentId 2 `
				-Id 3 `
				-Activity "Mailcount $($i) of $($findItemsResults.TotalCount)" `
				-Status "Mailfolder $fpath" `
				-PercentComplete ($perc)
			$global:mailCount += 1
			Process-Mail $miMailItems $i $folderItem $fpath $mailAddress
		}

		if ($findItemsResults.MoreAvailable -eq $true) {
			$ivItemView.Offset += $pageSize;
		}
	}
	while($findItemsResults.MoreAvailable -eq $true)# -and $i -lt 5)  
	Write-Trace "Process-MailsInFolder: End" 9
}

# Process individual mail and send result to STDOUT
function Process-Mail {
	param (
		$mailItem, 
		$a, 
		$folderItem, 
		$fpath, 
		$mailAddress
	)

	Write-Trace "Process-Mail: Start" 10
	$mailSender = "empty"
	$cpldTimeValObj = $null
	[string]$cpldTimeVal = ""
	#$DateTimeCreated = $mailItem.DateTimeCreated
	#$DateTimeSent = $mailItem.DateTimeSent
	$Categories = $mailItem.Categories
	#$LastModName = $mailItem.LastModifiedName
	#$FlagCompleteDateTime = $mailItem.Flag.CompleteDate
	#$FlagDueDateTime = $mailItem.Flag.DueDate
	$FlagStatus = [Microsoft.Exchange.WebServices.Data.ItemFlagStatus] $mailItem.Flag.FlagStatus
	$FlagStatusValue = $FlagStatus.ToString() #$FlagStatus.value__
	$cpldTimeValObj = [DateTime]0
	if ($mailItem.TryGetProperty($PidTagFlagCompleteTime, [ref] $cpldTimeValObj)) {
		$cpldTimeVal = $cpldTimeValObj.tostring($timeformat)
	}
	$CategoriesEnum = ""
	$CategoriesEnum = ($Categories -join ";")

	$folderId = $folderItem.DisplayName

	#$mailSubject = $mailItem.Subject
	#if($mailItem.Subject.Length -gt 200){
	#    $mailSubject = $mailItem.Subject.Remove(200)
	#}

	if ($fpath -eq "Inbox"){
		$folderId = "00";
	}
	else{
		$pos = $folderItem.DisplayName.IndexOf(" ")
		if ($pos -gt 0){
			$folderId = $folderItem.DisplayName.Substring(0, $pos)
		}
		else{
			if ($folderItem.DisplayName.Length -gt 5){
				$folderId = $folderItem.DisplayName.Remove(5)
			}
		}
	}
	if($folderId.Length -gt 5){
		$folderId = $folderId.Remove(5)
	}
	$mailSender = $mailItem.Sender.Address
	if($mailItem.Sender.Address -eq $null){
		$mailSender = 'empty'
	}

	$flagStartDateTime = $mailItem.Flag.StartDate.ToString($timeformat)
	#write-host "flagStartDateTime $($flagStartDateTime)"
	if (($flagStartDateTime -eq 0) -or ($flagStartDateTime  -eq "0001-01-01 12:00:00.000") -or  ($flagStartDateTime  -eq "0001-01-01 00:00:00.000")){
		$flagStartDateTime = ""
	}

	$InternetMessageID = $mailItem.InternetMessageID
	if($InternetMessageID -eq $null){
		$mailSender = 'empty'
	}
	Write-Trace "Process-Mail: InternetMessageID 0 $($InternetMessageID)" 10

	$newRow = New-Object PSObject -Property @{
		JobId = $jobid
		MessageId = $mailItem.Id
		InternetMessageID = $InternetMessageID 
		MailboxName = $mailAddress
		FolderPath = $fpath
		FolderName = $folderItem.DisplayName
		FolderID = $folderId
		Sender = $mailSender
		#MessageSubject = $mailSubject
		ReceivedDateTime = $mailItem.DateTimeReceived.ToString($timeformat)
		FlagStatus = $FlagStatusValue
		FlagCompletedDateTime = $cpldTimeVal
		FlagStartDateTime = $flagStartDateTime
		LastModifiedDateTime = $mailItem.LastModifiedTime.ToString($timeformat)
		Categories = $CategoriesEnum
    }

	# Send Result to STDOU for further processing
	
	
	
	if ((get-Date $newRow.ReceivedDateTime) -gt (get-Date $earliestReceivedDateTime)){
		if ($ignoreOutOfScopeMails) {
			if ($folderId -match "^(\d\d)" -or $folderId -match "^(\d\d_\d\d)") {
				$newRow
			}
		}
		else {
			$newRow
		}
	}
    # only for debugging purposes
    #if ($newRow -eq $null){
    #    write-host('Error')
    #    write-host('Counter = ' + $a)
    #    write-host('MailId = ' + $mailItem.Id)
    #    write-host('Mailbox = ' + $mailAddress)
    #    write-host('FolderPath = ' + $fpath)
    #    write-host('FolderName = ' + $folderItem.DisplayName)
    #    write-host('FolderID = ' + $folderId)
    #    write-host('Sender = ' + $mailSender)
    #    write-host('Subject = ' + $mailSubject)
    #    write-host('RcvdDT = ' + $mailItem.DateTimeReceived.ToString())
    #    write-host('FlagStatusVal = ' + $FlagStatusValue)
    #    write-host('FlagCompletedDateTime = ' + $cpldTimeVal.ToString())
    #    write-host('FlagStartDateTime = ' + $mailItem.Flag.StartDate.ToString())
    #    write-host('LastModifiedDateTime = ' + $mailItem.LastModifiedTime.ToString())
    #    write-host('Categories = ' + $CategoriesEnum)
    #}
	Write-Trace "Process-Mail: End" 10
}


#############################################
# Hauptprogramm
#############################################

Write-Trace "Collect-Mailproperties: Loading EWS_DLL"
Add-Type -Path $ewsDllLoc
#$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
Write-Trace " Create Exchange Service Object"
#$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)

##########################################################
# Getting config/list of mailbox addresses
##########################################################

Write-Trace "Loading Mailboxlist from $($configcsv) START"
[hashtable]$mailboxlist=@{}
foreach ($entry in (Import-Csv -path $configcsv | where {$_.active -eq "1"} )) {
	$mailboxlist.($entry.mailboxsmtp) = $entry.mailboxsmtp
	Write-Trace " Mailbox $($entry.mailboxsmtp)"
}

[int]$mailboxcount=0
$( foreach ($mailbox in $mailboxlist.keys){
    Write-Trace -Level 4 "Collect mails from Mailbox $($mailbox)"
	Write-Trace -Level 4 "    AutodAddress= $($mailboxlist.item($mailbox))"
    $mailboxcount++
    Write-Progress `
        -Id 1 `
        -Activity "Mailboxcount $($mailboxcount) of $($mailboxlist.count)" `
		-Status "Mailbox $mailbox" `
        -PercentComplete ($mailboxcount / $mailboxlist.count *100)
    Process-Mailbox($mailboxlist.item($mailbox))    
}) `
| export-csv `
	-path $exportcsvfile `
	-encoding unicode `
	-notypeinformation

Write-Trace "Results written to $exportcsvfile "

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0
Write-Trace "Collect-Mailproperties: End"