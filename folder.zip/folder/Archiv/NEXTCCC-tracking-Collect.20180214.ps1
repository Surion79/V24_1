# NEXTCCC-tracking-Collect.ps1
#
# Collects the last full hour of messages from all exchange message tracking logs and stores it in a CSV-File
#  if started ca 11:05am  the file will contain 10:00am-11:00am logs
#
# 20171019 FC Initial Version
# 20171109 FC Anpassung DateTime Format ausgabe mit [string]$timeformat = "yyyy-MM-dd hh:mm:ss.fff"
# 20171122 FC 
#	Anpassung DateTime Format ausgabe mit [string]$timeformat = "yyyy-MM-dd HH:mm:ss.fff"
#	Umstellung Transportserver Ermittlung ohne Edge Rolle
# 20171127 JGD
#	Changed JobId String to match a possible datetime format.
# Requires local Exchange PowerShell Snapins
#
# Optionen
#	Parallelisierung der Abfragen
#	InvokeCommand mit Remote Powershell um Tracking "lokal" zu filtern
#
# Sample to get logs from day 30 
#  1..29 | %{.\Collect-nextccmtracking.ps1 -starttimestamp (get-date).adddays(-($_)) -endtimestamp (get-date).adddays(-($_ -1)) -exportcsvfile "C:\Tasks\NEXTCCCReporting\trackingcsv\NEXTCCC-tracking-Collect.$($_).csv"}

# pending
#  CSV File anbd Start/End Date name conflict solve  for historical data
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),
	[string]$configcsv        = "C:\Tasks\NEXTCCCReporting\NEXTCCC-Mailboxlist.config.csv",
	$starttimestamp           = (get-date (get-date).addhours(-1) -format "MM/dd/yyyy HH:00:00"),   # start of this day
	$endtimestamp             = (get-date -format "MM/dd/yyyy HH:00:00"),   # 
    $exportcsvfile            = $null,   # name will be calculated in the code if no filename was specified
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff", 
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[string]$test="",     # Set to true to check Control-M Logic
	[string]$exchangeuri      = "https://outlook.miele.com/PowerShell/"
)

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')

##########################################################
# Helper Function to do tracing
##########################################################

Import-Module .\write-trace.psm1
set-TraceParameter `
	-tracefilename ".\logs\NEXTCCC-tracking-Collect.trace.$($jobidlog).log" `
	-levelfile 5 `
	-levelcon 5


Write-Trace "Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter exportcsvfile : $exportcsvfile"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Parameter timeformat    : $timeformat"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"


##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#$objectRef = $host.GetType().GetField(�externalHostRef�, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetProperty�
#$consoleHost = $objectRef.GetType().GetProperty(�Value�, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(�IsStandardOutputRedirected�, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#  $field = $consoleHost.GetType().GetField(�standardOutputWriter�, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(�standardErrorWriter�, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path ".\logs")) {mkdir ".\logs"}
[string]$transcriptfile = (".\logs\NEXTCCC-tracking-Collect.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

[string[]]$oldlogfilelist=""
get-item -path ".\logs\NEXTCCC-tracking-Collect.*.log" `
   | where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | %{$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-tracking-Collect:Start"
$starttime = get-date

##########################################################
# Loading Exchange environment
##########################################################
Write-Host "Loading Exchange Environment"
Write-Host "Creating Exchange Remote Session to $($exchangeuri)"

#Alt. not supportet https://blog.rmilne.ca/2015/01/28/directly-loading-exchange-2010-or-2013-snapin-is-not-supported/
#Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010

$session = new-pssession `
	-ConfigurationName "Microsoft.Exchange" `
	-ConnectionUri $exchangeuri `
	-Authentication negotiate
Write-Host "Import Exchange Remote Session Commandlets"
import-pssession -Session $session -AllowClobber | out-null


if ($error) {
	Write-Trace "Exitcode:8 Unable to load Exchange Snapins"
	$error
}

Write-Trace "Generating Exportrcsv Filename Start"
if ($exportcsvfile -eq $null) {
	$exportcsvfile = ".\trackingcsv\NEXTCCC-tracking-Collect.$(get-date (get-date).addhours(-1) -format "yyyyMMddHH00").csv"
	Write-Trace "Using calculated File: $exportcsvfile"
}
else {
	Write-Trace "Using given File: $exportcsvfile"
}
Write-Trace "Generating Exportrcsv Filename End"

Write-Trace "Set Scope to EntireForest"
#Set-AdServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue -PreferredGlobalCatalog $MsxGcDC
Set-ADServerSettings -ViewEntireForest $true

Write-Trace "Loading Transportservices Start"
$transportservices = Get-TransportService 
$transportservices = Get-ExchangeServer | where {$_.IsHubTransportServer -or $_.IsFrontendTransportServer}
$transportservices |`
    %{`
	   Write-Trace "Transportservice $($_.name)" -Level 4
	}
Write-Trace "Loading Transportservices Done. Total Services:$($transportservices.count)"

Write-Trace "Loading Mailboxlist from $($configcsv) START"
[string[]]$mailboxlist = Import-Csv -path $configcsv `
 | where {$_.active -eq "1"} `
 | group mailboxsmtp -NoElement `
 | select name -ExpandProperty name
Write-Trace "Loading Mailboxlist from $($configcsv) STOP  Total:$($mailboxlist.count)"
$mailboxlist `
	| %{Write-Trace -Level 3 "Mailbox: $($_)"  }

$mailboxcount=0
# Foreach endet daten nicht direkt in die Pipeline. Fehler An empty pipe element is not allowed. daher gesonderte Klammern  
$( foreach ($mailbox in $mailboxlist){
    Write-Trace -Level 4 "Tracking for Mailbox $($mailbox)"
    $mailboxcount++
    Write-Progress `
        -Id 1 `
        -Activity "Mailboxcount $($mailboxcount) of $($mailboxlist.count)" `
		-Status "Mailbox $mailbox" `
        -PercentComplete ($mailboxcount / $mailboxlist.count *100)
    $transportcount =0
    foreach ($transportservice in $transportservices){
        $transportcount ++
        $mailcount = 0
        Write-Trace  -Level 5 "Loading Messagetracking from Server $($transportservice.name)"
        Write-Progress `
            -Id 2 `
            -Activity "Transportcount $($transportcount) of $($transportservices.count)" `
			-Status "Transportservice $transportservice" `
            -PercentComplete ($transportcount / $transportservices.count *100)

		# Write-Trace -Level 5 "Processing DELIVER-Messages"
        # Get-MessageTrackingLog `
            # -Server $transportservice.name `
            # -Recipients $mailbox `
            # -Start $starttimestamp `
		    # -End   $endtimestamp `
            # -EventId AGENTINFO `
		    # -Resultsize unlimited `
        # | select 	@{name="JobID";expression={$jobid}},`
					# @{name="Direction";expression={"IN"}},`
					# MessageId,MessageSubject,NetworkMessageId,Sender,`
					# @{name="Recipients";expression={$_.Recipients -join ";"}},`
					# @{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
					# TotalBytes

		Get-MessageTrackingLog `
			-Server $transportservice.name `
			-Recipients $mailbox `
			-Start $starttimestamp `
			-End   $endtimestamp `
			-EventId DELIVER `
			-Resultsize unlimited `
       | select 	@{name="JobID";expression={$jobid}},`
					@{name="Direction";expression={"IN"}},`
					MessageId,MessageSubject,NetworkMessageId,Sender,`
					@{name="Recipients";expression={$_.Recipients -join ";"}},`
					@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
					TotalBytes

		# Write-Trace  -Level 5 "Processing SUBMIT-Messages"
		# Get-MessageTrackingLog `
            # -Server $transportservice.name `
            # -Sender $mailbox `
			# -Start $starttimestamp `
		    # -End   $endtimestamp `
            # -EventId AGENTINFO `
		    # -Resultsize unlimited `
        # | select 	@{Name="JobID";Expression={$jobid}},`
					# @{name="Direction";expression={"OUT"}},`
					# MessageId,MessageSubject,NetworkMessageId,Sender,`
					# @{name="Recipients";expression={$_.Recipients -join ";"}},`
					# @{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
					# TotalBytes

		Write-Trace  -Level 5 "Processing SUBMIT-Messages"
		Get-MessageTrackingLog `
			-Server $transportservice.name `
			-Sender $mailbox `
			-Start $starttimestamp `
			-End   $endtimestamp `
			-EventId SUBMIT `
			-Resultsize unlimited `
        | select 	@{Name="JobID";Expression={$jobid}},`
					@{name="Direction";expression={"OUT"}},`
					MessageId,MessageSubject,NetworkMessageId,Sender,`
					@{name="Recipients";expression={$_.Recipients -join ";"}},`
					@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
					TotalBytes

		Write-Trace  -Level 3 "Loading Messagetracking from Server $($transportservice.name) DONE"
    }
}) `
| export-csv `
	-path $exportcsvfile `
	-encoding unicode `
	-notypeinformation

Write-Trace "Results written to $exportcsvfile "

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0