# convertto-bcpcsv
#
# Simple modul to convert a Table-Input to a XML-File
# 20150403 frank.carius@netatwork.de  Initial Version with parameter for files
# 20171108 frank.carius@netatwork.de  Change to Pipeline Processing
# 20171109 frank.carius@netatwork.de  Add Escaping for five special characters

[CmdletBinding()]
param (
	[parameter(ValueFromPipeline=$True)]
	[string[]]$line,
	[string]$delimiter= "`t",		# this is the default delimiter of BCP Input files
	[switch]$includeheader = $true	# bcp can skip the first line with -F 2
)

begin{
	write-verbose "convertto-bcpcsv:Start"
	[long]$count=0
	[array]$header=@()
}

process{
	$count++
	if ($count%100 -eq 0 ) {
		write-verbose "convertto-bcpcsv:Line $count"
	}
	
	if ($header.count -eq 0) {
		write-verbose "convertto-bcpcsv:Collect Header"
		foreach ($property in ($_ | gm -MemberType noteproperty)) {
			write-verbose "convertto-bcpcsv:  AddHeader $($property.name)"
			$header += $property.name
		}
	}

	if ($includeheader -and ($count -eq 1)){
		write-verbose "convertto-bcpcsv:  Add Header to Output"
		$header -join $delimiter
	}
	
	[array]$outline = @()
	foreach ($property in $header) {
		[string]$value = $_.($property)
		$value = $value.replace("`t","")
		$outline+= ($delimiter + $value)
	}
	$outline -join $delimiter
}
end {
	write-verbose "convertto-bcpcsv::End"
}
