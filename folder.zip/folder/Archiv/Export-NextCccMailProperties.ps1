# Export-nextcccsql
#
# Export CSV-Fields to SQL Tables
#
# 20171019 FC Initial Version
# 20171106 JGD	Added ews data
# 20171108 FC Kleine Anpassungn
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/
#
# http://www.sqlteam.com/article/fast-csv-import-in-powershell-to-sql-server


# Imrot Code based on "Import Large CSVs into SQL Server Using PowerShell"
# https://blog.netnerds.net/2014/07/import-large-csvs-into-sql-server-using-powershell/
#
# How to use the server name parameter in a connection string to specify the client network library
# https://support.microsoft.com/en-us/help/313295/how-to-use-the-server-name-parameter-in-a-connection-string-to-specify
#
# Using C# And SqlBulkCopy To Import CSV Data Into SQL Server
# https://johnnycode.com/2013/08/19/using-c-sharp-sqlbulkcopy-to-import-csv-data-sql-server/
#
# Invoke-SQLBulkCopy.ps1
# https://github.com/RamblingCookieMonster/PowerShell/blob/master/Invoke-SQLBulkCopy.ps1
#
# Optimizing Bulk Import Performance
# https://technet.microsoft.com/en-us/library/ms190421(v=sql.105).aspx
#
# Prerequisites for Minimal Logging in Bulk Import
# https://docs.microsoft.com/en-us/sql/relational-databases/import-export/prerequisites-for-minimal-logging-in-bulk-import
#
# The Data Loading Performance Guide
# https://technet.microsoft.com/en-us/library/dd425070(v=sql.100).aspx

[CMDLetBinding()]
param (
	[string]$trackingcsvpattern = "C:\Tasks\NEXTCCCReporting\trackingcsv\Collect-nextccctracking.*.csv",
	[string]$ewscsvpattern = "C:\Tasks\NEXTCCCReporting\ewscsv\Collect-NextCccMailProperties.*.csv", 
	[string]$SQLServerInstance = "MSSQL2017DEV" ,
	[string]$SQLServer = "DEGTSAW5W.de.miele.net" ,
	[string]$Database= "MailKpiTest",
	[int]$batchsize = 500,
	[int]$debuglevel=3, 
	[int]$transcriptpurgedays = 30,   # Purge log files older than these days
	[switch]$importtracking = $false,
	[switch]$importmaildata = $false,
	[string]$test=""     # Set to true to check Control-M Logic
)

set-psdebug -strict
$error.clear()
[boolean]$errorfound=$false

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# Import Race Modul to log activities
Import-Module .\write-trace.psm1
set-TraceParameter `
	-tracefilename ".\logs\Export-nextcccsql.$(get-date -format "yyyy-MM-dd-HH-mm-ss-fff").log" `
	-levelfile 8 `
	-levelcon $debuglevel

Write-Trace "Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter exportcsvfile : $exportcsvfile"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"


##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#$objectRef = $host.GetType().GetField(�externalHostRef�, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetProperty�
#$consoleHost = $objectRef.GetType().GetProperty(�Value�, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(�IsStandardOutputRedirected�, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#  $field = $consoleHost.GetType().GetField(�standardOutputWriter�, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(�standardErrorWriter�, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path ".\logs")) {mkdir ".\logs"}
[string]$transcriptfile = (".\logs\Export-nextcccsql."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

[string[]]$oldlogfilelist=""
get-item -path ".\logs\Export-nextcccsql.*.log" `
   | where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | %{$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "Export-nextcccsql:Start"
$starttime = get-date

if ($importtracking) {
	Write-Trace "Start processing Tracking CSV START"
	# Build the sqlbulkcopy connection, and set the timeout to infinite 
	$sqlconnectionstring = "Data Source=$($sqlserver)\$($SQLServerInstance);Integrated Security=true;Database=$($database)" 
	Write-Trace "connectionstring String  $($sqlconnectionstring)"
	$bulkcopy = new-object ("Data.SqlClient.Sqlbulkcopy") $sqlconnectionstring 
	$bulkcopy.DestinationTableName = "MessageTracking" 
	$bulkcopy.bulkcopyTimeout = 0 
	$bulkcopy.batchsize = $batchsize 
	$bulkcopy.EnableStreaming = 1 

	write-trace "Creating Datatable for Import START"
	$datatable = New-Object "System.Data.DataTable" 
	write-trace -level 4 "Adding Colums"
	$null=$datatable.Columns.Add("JobID", ([String]))
	$null=$datatable.Columns.Add("Direction", ([String]))
	$null=$datatable.Columns.Add("MessageId", ([String]))
	$null=$datatable.Columns.Add("MessageSubject", ([String]))
	$null=$datatable.Columns.Add("NetworkMessageId", ([String]))
	$null=$datatable.Columns.Add("Sender", ([String]))
	$null=$datatable.Columns.Add("Recipients", ([String]))
	$null=$datatable.Columns.Add("Timestamp", ([datetime]))
	$null=$datatable.Columns.Add("TotalBytes", ([long]))
	write-trace "Creating Datatable for Import END"

	foreach ($csvfile in (get-childitem -path $trackingcsvpattern)){
		Write-Trace  -level 3 "Processing $($csvfile.fullname)"
		$error.clear()   # clear 
		$count = 0
		write-trace "Start Import CSV of $($csvfile.fullname)"
		import-csv $csvfile.fullname| % { 
			$count++
			#if (($count % 10) -eq 0) { 
			#	write-host "." -nonewline
			#}
			$row = $datatable.NewRow() 
			foreach ($property in ($row| gm -MemberType property)){
				write-trace  -level 6 "Add Property $($property.name)  Value: $($_.($property.name))"
				if ($_.($property.name) -ne ""){
					$row.($property.name) = $_.($property.name)
				}
			}

			write-trace  -level 4 "Add Row $($count) to Datatable"
			$null= $datatable.Rows.Add($row)   
			if (($count % $batchsize) -eq 0) { 
				write-trace  -level 3 "$count Writing Datatable to Server"
				$bulkcopy.WriteToServer($datatable) 
				if ($error) {
					write-trace "$count Error during BulkImport $error"
					$error
					$errorfound=$true
				}
				else {
					write-trace "$count in der Datatablerows have been inserted in $($stopwatch.Elapsed.ToString())."; 
					$datatable.Clear() 
				}
			} 
		}
	 
		# Add in all the remaining rows since the last clear 
		if($datatable.Rows.Count -gt 0) { 
			$bulkcopy.WriteToServer($datatable) 
			$datatable.Clear() 
		} 
		write-trace "Records imported: $count"
		write-trace "END Import CSV of $($csvfile.fullname)"
		if (!$error) {
			write-trace "Import Successful. Move CSV-File"
			move-item $csvfile.fullname ($csvfile.Directoryname +"\done")
			if ($error) {
				write-trace "Error moving CSV-File"
				$errorfound=$true
				$error.clear()
			}
		}
		else {
			write-trace "ERROR during Impert Skip Rename CSV-File"
			$errorfound=$true
			$error.clear()
		}
	}
	Write-Trace "Start processing Tracking CSV END"
}

if ($importmaildata) {
	Write-Trace "Start processing EWSCSV START"

	$sqlconnectionstring = "Data Source=$($sqlserver)\$($SQLServerInstance);Integrated Security=true;Database=$($database)" 
	Write-Trace "connectionstring String  $($sqlconnectionstring)"
	$bulkcopy = new-object ("Data.SqlClient.Sqlbulkcopy") $sqlconnectionstring 
	$bulkcopy.DestinationTableName = "MailProperties" 
	$bulkcopy.bulkcopyTimeout = 0 
	$bulkcopy.batchsize = $batchsize 
	$bulkcopy.EnableStreaming = 1 

	write-trace "Creating Datatable for Import START"
	$datatable = New-Object "System.Data.DataTable" 
	write-trace -level 4 "Adding Colums"
	$null=$datatable.Columns.Add("JobID", ([String]))
	$null=$datatable.Columns.Add("MessageId", ([String]))
	$null=$datatable.Columns.Add("InternetMessageID", ([string]))
	$null=$datatable.Columns.Add("ReceivedDateTime", ([datetime]))
	$null=$datatable.Columns.Add("LastModifiedDateTime", ([datetime]))
	#$null=$datatable.Columns.Add("MessageSubject", ([String]))
	$null=$datatable.Columns.Add("Sender", ([String]))
	$null=$datatable.Columns.Add("MailboxName", ([String]))
	$null=$datatable.Columns.Add("FlagStatus", ([String]))
	$null=$datatable.Columns.Add("FlagStartDateTime", ([datetime]))
	$null=$datatable.Columns.Add("FlagCompletedDateTime", ([datetime]))
	$null=$datatable.Columns.Add("FolderPath", ([String]))
	$null=$datatable.Columns.Add("FolderId", ([String]))
	$null=$datatable.Columns.Add("FolderName", ([String]))
	$null=$datatable.Columns.Add("Categories", ([String]))
	write-trace "Creating Datatable for Import END"

	foreach ($csvfile in (get-childitem -path $ewscsvpattern)){
		Write-Trace "Processing $($csvfile.fullname)" -level 4
			$error.clear()   # clear 
		$count = 0
		write-trace "Start Import CSV of $($csvfile.fullname)"
		import-csv $csvfile.fullname| % { 
		#import-csv "C:\Tasks\NEXTCCCReporting\trackingcsv\Collect-nextccctracking.201710191400.csv" | % { 
			$count++
			#if (($count % 10) -eq 0) { 
			#	write-host "." -nonewline
			#}
			$row = $datatable.NewRow() 
			foreach ($property in ($row| gm -MemberType property)){
				write-trace  -level 6 "Add Property $($property.name)  Value: $($_.($property.name))"
				if ($_.($property.name) -ne ""){
					$row.($property.name) = ("" + $_.($property.name))
				}
			}

			write-trace  -level 4 "Add Row $($count) to Datatable"
			$null= $datatable.Rows.Add($row)   
			if (($count % $batchsize) -eq 0) { 
				write-trace  -level 3 "$count Writing Datatable to Server"
				$bulkcopy.WriteToServer($datatable) 
				if ($error) {
					write-trace "$count Error during BulkImport $error"
					$error
					$errorfound=$true
				}
				else {
					write-trace "$count in der Datatablerows have been inserted in $($stopwatch.Elapsed.ToString())."; 
					$datatable.Clear() 
				}
			} 
		}
	 
		# Add in all the remaining rows since the last clear 
		if($datatable.Rows.Count -gt 0) { 
			$bulkcopy.WriteToServer($datatable) 
			$datatable.Clear() 
		} 
		write-trace "Records imported: $count"
		write-trace "END Import CSV of $($csvfile.fullname)"
		if (!$error) {
			write-trace "Import Successful. Move CSV-File"
			move-item $csvfile.fullname ($csvfile.Directoryname +"\done")
			if ($error) {
				write-trace "Error moving CSV-File"
				$errorfound=$true
				$error.clear()
			}
		}
		else {
			write-trace "ERROR during Impert Skip Rename CSV-File"
			$errorfound=$true
			$error.clear()
		}
	}
	Write-Trace "Start processing EWSCSV END"
}

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($errorfound) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0