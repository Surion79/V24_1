﻿# NEXTCCC-MakeFolder.ps1
#
# 20171206  FC
#	Initial Version
# Optionen
#	Parallelisierung der Abfragen
# 20180116 FC Zusammenfassung der Mails
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),
	[string]$configcsv        = "C:\Tasks\NEXTCCCReporting\NEXTCCC-MakeFolder.config.csv",
    [string]$ewsDllLoc        = "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll",
	[switch]$enforceall       = $false, 
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff", 
	[string]$smtpserver       = "relay.miele.com",
	[string]$smtpfrom         = "migteam@miele.com",
	[string]$test=""     # Set to true to check Control-M Logic
)

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')

##########################################################
# Helper Function to do tracing
##########################################################

Import-Module .\write-trace.psm1
set-TraceParameter `
	-tracefilename ".\logs\NEXTCCC-MakeFolder.trace.$($jobidlog).log" `
	-levelfile 5 `
	-levelcon 8


Write-Trace "NEXTCCC-MakeFolder: Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"

##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#$objectRef = $host.GetType().GetField(“externalHostRef”, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetProperty”
#$consoleHost = $objectRef.GetType().GetProperty(“Value”, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(“IsStandardOutputRedirected”, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#  $field = $consoleHost.GetType().GetField(“standardOutputWriter”, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(“standardErrorWriter”, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path ".\logs")) {mkdir ".\logs"}
[string]$transcriptfile = (".\logs\NEXTCCC-MakeFolder.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace " Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Cleanup old Logfiles"
[string[]]$oldlogfilelist=""
get-item -path ".\logs\NEXTCCC-MakeFolder.*.log" `
	| where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
	| %{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  Logfile $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old LogFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old LogFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old LogFile: $($oldlogfile)"
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-MakeFolder:Start"
$starttime = get-date


#############################################
# Hauptprogramm
#############################################

Write-Trace "NEXTCCC-MakeFolder: Loading EWS_DLL"
Add-Type -Path $ewsDllLoc

##########################################################
# Getting config/list of mailbox addresses
##########################################################

Write-Trace "Loading ConfigFILE from $($configcsv) START"
$configlist = Import-Csv -path $configcsv | where {$_.active -eq "1"}
Write-Trace "Loading ConfigFILE from $($configcsv) END"

[int]$totalmailbox=0
[int]$totalfound=0
[int]$totalmissing=0
[int]$totalcreated=0
[int]$totalerror=0


foreach ($line in $configlist){
#foreach ($mailbox in $mailboxlist.keys){
	$mailbox = $line.MailboxSMTP
	Write-Trace -Level 4 "Mailbox $($mailbox)"
	$totalmailbox++
	Write-Progress `
		-Id 1 `
		-Activity "totalmailbox $($totalmailbox) of $($mailboxlist.count)" `
		-Status "Mailbox $mailbox" `
		-PercentComplete ($totalmailbox / $configlist.count *100)

	# 
	#  Connect to Exchange using EWS with Impersonation
	#
	Write-Trace " Initializing EWS"
    $ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
    $ewsservice = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
    $ewsservice.UseDefaultCredentials = $true
	$ewsservice.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$mailbox); 
	Write-Trace " Try Autodiscover for $($mailbox)"
	try {
		#$service.TraceEnabled = $true
		$ewsservice.AutodiscoverUrl($mailbox,{$true})
		#$service.TraceEnabled = $false
		Write-Trace "  AutoD Success $($service.Url)"
	}
	catch {
		write-warning " Unable to get Autodiscover entry"
		$error
		$totalerror++
		#$error.clear()
	}
	
	if ($ewsservice.url) {
		Write-Trace -Level 4 "    EWS Service established to $($ewsservice.url)"
		
		Write-Trace -Level 4 "    Loading Folder template File $($line.templatefile)"
		$folderlist = import-csv $line.templatefile
		
		foreach ($entry in $folderlist){
			Write-Trace -Level 3 "Processing $($MailboxSMTP)::$($entry.FolderPath)"
			$rootfolderid = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::inbox)   
			$rootfolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($ewsservice,$rootfolderid)  
			$FolderView = new-object Microsoft.Exchange.WebServices.Data.FolderView(1000) 
			$fldArray = $entry.FolderPath.Split("\") 
			 #Loop through the Split Array and do a Search for each level of folder 
			$currentfolder = $rootfolder
			for ($level = 1; $level -lt $fldArray.Length; $level++) { 
				[string]$currentfolderfullname = ($fldArray[0..$level]) -join "\"
				write-trace -level 5 "$($currentfolderfullname)"
				write-trace -level 5 "  Level: $($level)  Name $($fldArray[$level])"
				# get all subfolders of current folder
				$findFolderResults = $currentfolder.FindFolders($FolderView) 
				$nextfolder=$null
				if ($findFolderResults.TotalCount -gt 0){
					write-trace -level 6 " Parsing Folder Results"
					$nextfolder = ($findFolderResults.Folders | where {$_.displayname.split(" ")[0] -eq ($fldArray[$level].split(" ")[0])}) | select -First 1
				}
				if ($nextfolder) {
					write-trace -level 6 "  Found"
					$currentfolder = $nextfolder
					if ($level -eq ($fldArray.Length -1)) {
						write-trace -level 4 "complete Path found"
						$totalfound++
					}
				}
				else{ 
					write-trace -level 6 " folder $($currentfolderfullname) not found"
					if (($line.enforce -eq "1") -or $enforceall) {
						write-trace -level 4 "Add Folder $($currentfolderfullname)"
						$totalcreated++
						$NewFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($ewsservice) 
						$NewFolder.DisplayName = $fldArray[$level]
						$NewFolder.FolderClass = "IPF.Note"
						$NewFolder.Save($currentfolder.Id)  
						$currentfolder = $newfolder
						if ($line.notifySMTP -ne "") {
							write-trace -level 6 " Send Mail to $($line.notifySMTP)"
							send-mailmessage `
								-smtpServer $smtpserver	`
								-from $smtpfrom `
								-to $line.notifySMTP.split(",") `
								-subject "NextCCC-MakeFolder: Folder Created $($Mailbox)::$($currentfolderfullname)" `
								-body 	("NextCCC-MakeFolder: Folder Created $($Mailbox)::$($currentfolderfullname)`r`n "+ `
										"Mailbox       $($Mailbox) `r`n "+ `
										"FolderPath    $($entry.FolderPath)`r`n "+ `
										"Currentfolder $($currentfolder.displayname)`r`n "+ `
										"Subfolder     $($entry.foldername) `r`n ") 						
						}
					}
					else {
						write-trace -level 4 "Report Missing Folder and stop processing of that line"
						$totalmissing++
						$level = $fldArray.Length;
						if ($line.notifySMTP -ne "") {
							write-trace -level 6 " Send Mail to $($line.notifySMTP)"
							send-mailmessage `
								-smtpServer $smtpserver	`
								-from $smtpfrom `
								-to $line.notifySMTP.split(",") `
								-subject "NextCCC-MakeFolder: Folder missing $($Mailbox)::$($currentfolderfullname)" `
								-body 	("NextCCC-MakeFolder: Folder missing $($Mailbox)::$($currentfolderfullname)`r`n "+ `
										"Mailbox       $($Mailbox) `r`n "+ `
										"FolderPath    $($entry.FolderPath)`r`n "+ `
										"Currentfolder $($currentfolder.displayname)`r`n "+ `
										"Subfolder     $($entry.foldername) `r`n ") 
						}
					}
				}     
			} 
			write-trace -level 4 " Done Line"
		}
	}
	else {
		Write-Warning "    No EWS Service Available"
		Write-Trace -Level 4 "    No EWS Service Found"
		[int]$totalerror++
	}
}

Write-Trace "Total mailbox $($totalmailbox)"
Write-Trace "Total found   $($totalfound)"
Write-Trace "Total missing $($totalmissing)"
Write-Trace "Total created $($totalcreated)"
Write-Trace "Total error   $($totalerror)"
Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0
Write-Trace "NEXTCCC-MakeFolder: Start"