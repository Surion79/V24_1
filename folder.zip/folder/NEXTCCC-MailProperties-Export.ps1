# NEXTCCC-MailProperties-Export.ps1
#
# Export CSV-Fields to SQL Tables using BCP
#
# 20171109 FC Initial Version
# 20180214 FC Verschieben der Error-Dateien im Fehlerfall um Reimport zu verhindern
# 20180605 AS Prüfung ob Stored Procedure ReorgData läuft mittels IsReorgDataRunning Funktion, 
#				die im Modul NEXTCCC-MailPropertiesFunctionsModule.ps1 definiert ist

[CMDLetBinding()]
param (	
	[string]$configFileName   = "NEXTCCC-MailProperties-ExportConfig.xml" ,
	[int]$exportIterations = 3,	 # number of iterations to perform export in one run of the script	
	[int]$timeframe = 1200, #In Minutes.Timeframe to export data to SQL server. Export process ends when timeframe is exceeded.
	[int]$debuglevel          = 3, 
	[int]$transcriptpurgedays = 10,   # Purge log files older than these days
	[string]$test="",     # Set to true to check Control-M Logic
	[string]$SQLServer        = "DEGTDBCL31VPEMS.de.miele.net\PEMS"
)

set-psdebug -strict
$error.clear()
[boolean]$errorfound=$false

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# Import Race Modul to log activities
Import-Module "$($PSScriptRoot)\write-trace.psm1" -force
set-TraceParameter `
	-tracefilename "$($PSScriptRoot)\logs.MailProperties-Export\NEXTCCC-MailProperties-Export.$(get-date -format "yyyy-MM-dd-HH-mm-ss-fff").log" `
	-levelfile 5 `
	-levelcon $debuglevel

Write-Trace "Start"
Write-Trace "Scriptname                   : $($MyInvocation.InvocationName)"
Write-Trace "Servername                   : $($env:COMPUTERNAME)"
Write-Trace "Username                     : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter configFileName     : $configFileName"
Write-Trace "Tracefile                    : $((get-traceparameter).tracefilename)"

##########################################################
# Enable Transcript and cleanup older files
##########################################################
if (!(test-path "$($PSScriptRoot)\logs.MailProperties-Export")) {mkdir "$($PSScriptRoot)\logs.MailProperties-Export"}
[string]$transcriptfile = ("$($PSScriptRoot)\logs.MailProperties-Export\NEXTCCC-MailProperties-Export.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Purging old Logfile"

[string[]]$oldlogfilelist=""
get-item -path "$($PSScriptRoot)\logs.MailProperties-Export\NEXTCCC-MailProperties-Export.*.log" `
   | where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | %{$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}


#Import central functions module to load function "IsStoredProcedureRunning"
Import-Module "$($PSScriptRoot)\NEXTCCC-MailPropertiesFunctionsModule.psm1" -NoClobber -Verbose


####################################################################
# check if "sp_GetDataImportStatus " is running #
####################################################################

[boolean]$dataImportStatusRunning = IsStoredProcedureRunning -SPName "sp_GetDataImportStatus"
Write-Trace "dataImportStatusRunning is: $($dataImportStatusRunning)"
if($dataImportStatusRunning -eq $false)
{
	##################################################################
	# run the sp_StartDataImport Function to Lock Reorg and Update sp
	##################################################################
	Write-Trace "Set DataImportStatus via sp_StartDataImport"
	$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
	$SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=email_kpi;Integrated Security=true";
	try {
		$SqlConnection.Open()
	}
	catch
	{
		Write-Trace "Could not Open SQL Connection with $($SqlConnection.ConnectionString) -exeting"
		Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
		Write-Trace "Exception Message: $($_.Exception.Message)"
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 4		
	}

	$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
	$SqlCmd.CommandText = "sp_StartDataImport"
	$SqlCmd.Connection = $SqlConnection
	$sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
	$sqlCmd.CommandTimeout = 60
	try{
		$result = $sqlCmd.ExecuteNonQuery()
	}
	catch{
		Write-Trace "Could not execute sp_StartDataImport Command - Result $($result) -exeting"
		Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
		Write-Trace "Exception Message: $($_.Exception.Message)"
		Write-Trace "Exit Application"
		$SqlConnection.Close()
		stop-transcript | out-null
		exit 4	
	}

	if ($result -ne -1) {
		Write-Trace "Stored Procedure sp_StartDataImport ended with Result : $($Result) - Exiting"
		Write-Trace "Exit Application"
		$SqlConnection.Close()
		stop-transcript | out-null
		exit 4
	}
	Write-Trace "Stored Procedure sp_StartDataImport ended with Result : $($Result)"
	$SqlConnection.Close()
} elseif ($dataImportStatusRunning -eq $true) {
    Write-Trace "Stored Procedure dataImportStatusRunning is allready running."
}


####################################################################
# check if "sp_GetDataImportStatus " set properly #
####################################################################

[boolean]$dataImportStatusRunning = IsStoredProcedureRunning -SPName "sp_GetDataImportStatus"
Write-Trace "dataImportStatusRunning is: $($dataImportStatusRunning)"
if($dataImportStatusRunning -eq $false)
{
	Write-Trace "Stored Procedure dataImportStatusRunning is not running. Export will not be started. Exit."
	stop-transcript | out-null
	exit
} elseif ($dataImportStatusRunning -eq $true) {
    Write-Trace "Stored Procedure dataImportStatusRunning is running."
}

####################################################################
# check if the stored procedure "sp_GetReorgDataStatus" is running #
####################################################################

[boolean]$reorgDataRunning = IsStoredProcedureRunning -SPName "sp_GetReorgDataStatus"
Write-Trace "reorgDataRunning is: $($reorgDataRunning)"
if($reorgDataRunning -eq $false)
{
    Write-Trace "Stored Procedure ReorgData is not running."
} elseif ($reorgDataRunning -eq $true) {
	Write-Trace "Stored Procedure ReorgData is running. Export will not be started. Exit."
	stop-transcript | out-null
	exit
}

###################################################################################
# check if the stored procedure "sp_GetUpdateMailPropertiesDataStatus" is running #
###################################################################################
#Import central functions module to load function "IsStoredProcedureRunning"
#Import-Module "$($PSScriptRoot)\NEXTCCC-MailPropertiesFunctionsModule.psm1" -NoClobber -Verbose

[boolean]$getUpdateMailPropertiesDataStatusRunning = IsStoredProcedureRunning -SPName "sp_GetUpdateMailPropertiesDataStatus"
Write-Trace "GetUpdateMailPropertiesDataStatusRunning is: $($getUpdateMailPropertiesDataStatusRunning)"
if($getUpdateMailPropertiesDataStatusRunning -eq $false)
{
    Write-Trace "Stored Procedure getUpdateMailPropertiesDataStatus is not running. Export will be started."
} elseif ($getUpdateMailPropertiesDataStatusRunning -eq $true) {
	Write-Trace "Stored Procedure getUpdateMailPropertiesDataStatus is running. Export will not be started. Exit."
	stop-transcript | out-null
	exit
}

function EndDataImport ($SQLServer)
{

	Write-Trace "Set DataImportStatus via sp_EndDataImport"

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=email_kpi;Integrated Security=true";
try {
	$SqlConnection.Open()
}
catch
{
	Write-Trace "Could not Open SQL Connection with $($SqlConnection.ConnectionString) -exeting"
	Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
	Write-Trace "Exception Message: $($_.Exception.Message)"
	Write-Trace "Exit Application"
	stop-transcript | out-null
	exit 4		
}

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = "sp_EndDataImport"
$SqlCmd.Connection = $SqlConnection
$sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
$sqlCmd.CommandTimeout = 60
try{
	$result = $sqlCmd.ExecuteNonQuery()
}
catch{
	Write-Trace "Could not execute sp_EndDataImport Command - Result $($result) -exeting"
	Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
	Write-Trace "Exception Message: $($_.Exception.Message)"
	Write-Trace "Exit Application"
	$SqlConnection.Close()
	stop-transcript | out-null
	exit 4	
}

if ($result -ne -1) {
	Write-Trace "Stored Procedure sp_EndDataImport ended with Result : $($Result) - Exiting"
	Write-Trace "Exit Application"
	$SqlConnection.Close()
	stop-transcript | out-null
	exit 4
}
Write-Trace "Stored Procedure sp_EndDataImport ended with Result : $($Result)"
}

function CreateDummyCSVInputFile($directory, $filterstring, $replacedfilterstring)
{
    $filesCollection=@(get-childitem -path $directory -File -Filter "*$filterstring*.csv")
    $firstFileFullName = $filesCollection[0].FullName
    $firstFile = Import-Csv -Path $firstFileFullName    
    $dummyFileFullname = $firstFileFullName.Replace($filterstring, $replacedfilterstring)
    $firstFile[0] | Export-Csv -Path $dummyFileFullname -NoTypeInformation

}

####################################################################################
# Function CreateImportDataTable to create a new DataTable from csvFilesCollection #
####################################################################################
function CreateImportDataTable($configurationFilePath, $csvFilesToExport)
{
	$importTable = New-Object system.Data.DataTable "NewMailProperties"
	#Write-Trace "Getting Columns from configuration file:"
	[Reflection.Assembly]::LoadWithPartialName("System.Xml.Linq") | Out-Null
	#using XDocument due to performance issues with XML reader solution
	$configurationFile = [System.Xml.Linq.XDocument]::Load($configurationFilePath)
	#$columnToDATATYPEMapping is used for faster read of DATATYPE value by column name later in CSV file columns iteration
	$columnToDATATYPEMapping = @{}
	foreach($column in $configurationFile.Descendants("COLUMN"))
	{
		[string] $name = $column.Attribute("NAME").Value		
		[string] $datatype = $column.Attribute("DATATYPE").Value

		#create mapping of column NAME to column DATATYPE value
		$columnToDATATYPEMapping.Add($name, $datatype)
		
		Write-Trace "DATATYPE: $($datatype) | NAME: $($name)"		
		$newcol = New-Object System.Data.DataColumn $name
		$newcol.DataType = [System.Type]$datatype
		$importTable.Columns.Add($newCol)
	}                     
	#Process the list of files found in the directory.             
	#Write-Trace "Process the list of files found in the ExportFiles directory"           
	foreach($fileName in $csvFilesToExport)                
	{
		$fileNameFullName = $fileName.FullName
		Write-Trace "Processing file: $($fileNameFullName)"				
		$csvFile = Import-Csv -Path $fileNameFullName
		foreach($line in $csvFile)
		{
			$row = $importTable.NewRow()                                             
			foreach($col in $importTable.Columns)
			{  				
				$columnName = $col.ColumnName	
				#Write-Trace "Performing column $($columnName)"			
				$dataType = $columnToDATATYPEMapping[$columnName]
				#Write-Trace "datatype value is: $($dataType)"
				#Check type of column
				if($dataType -like "DateTime") 
				{   
					#Type of column is DateTime
					#Write-Trace "column value is: $($line.$columnName)"
					if($line.$columnName -eq "")
					{    
						#Value is empty, setting to DBNull						
						$row[$columnName] = [System.DBNull]::Value
					} 
					else 
					{	
						#Parsing DateTime and setting the value
						$dateValue = [datetime]::ParseExact($line.$columnName, "yyyy-MM-dd HH:mm:ss.fff",[System.Globalization.CultureInfo]::InvariantCulture)                                       
						$row[$columnName] = $dateValue;
						#Write-Trace "Column: $($columnName) | Value: $($dateValue)"
					}  
				}   
				else
				{       
					#Type of column is not DateTime. Setting value directly					
					$row[$columnName] = $line.$columnName
					#Write-Trace "Column: $($columnName) | Value: $($line.$columnName)"
				} 
			}  
			#Adding row to ImportTable
			$importTable.Rows.Add($row);
		}
	}	
	#Must use return with , to return $importTable as DataTable and not as Object[]
	return , $importTable;
}

################################################################################
# Function ExportMailProperties to export mailproperties to SQL Server via BCP #
################################################################################
function ExportMailProperties([string]$connectionString, [string] $dbTableName, [system.Data.DataTable]$mailPropertiesDataTable)
        {            
			#Open a sourceConnection to the database. 			        
            Write-Trace "Open a sourceConnection to the database"
			$connection = New-Object System.Data.SqlClient.SqlConnection
			$connection.ConnectionString = $connectionString			               
			try{
				$connection.Open()
			}  
			catch
			{
				Write-Trace "Error while opening a sourceConnection to the database"
				Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
				Write-Trace "Exception Message: $($_.Exception.Message)"
				return $false
			}
		
			$bulkcopy = New-Object Data.SqlClient.SqlBulkCopy -argumentlist $connection,$([System.Data.SqlClient.SqlBulkCopyOptions]::FireTriggers -bor 0),$null
			$bulkCopy.DestinationTableName = $dbTableName;
			$bulkCopy.BatchSize = 1000; #Number of rows in each batch. At the end of each batch, the rows in the batch are sent to the server.
			$bulkCopy.BulkCopyTimeout = 240;  #Number of seconds for the operation to complete before it times out. The default is 30 seconds. 
			
			#ColumnMapping
			foreach ($column in $mailPropertiesDataTable.Columns) 
			{ 	
				$bulkCopy.ColumnMappings.Add((New-Object System.Data.SqlClient.SqlBulkCopyColumnMapping($column.ColumnName, $column.ColumnName))) | Out-Null
			} 
			
			try
			{                        
				Write-Trace "Writing data to DB Table $($dbTableName)"
				#Write data from the source to the destination.
				$bulkCopy.WriteToServer($mailPropertiesDataTable);
			}
			catch
			{
				Write-Trace "Failed writing data to DB Table $($dbTableName)"
				Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
				Write-Trace "Exception Message: $($_.Exception.Message)"
				$bulkcopy.Dispose()			
				$connection.Close()
				return $false
			}

			Write-Trace "Successfully written data to DB Table $($dbTableName)"

			$bulkcopy.Dispose()			
			$connection.Close()
			return $true
		}

#################################################################################################
# Function FileExistsInTargetFolder to check if files already exists in "done" directory #
#################################################################################################
function FileExistsInTargetFolder($csvFilesToMove, $exportFilesDirectory ,$finishedFilesDirectory)
{   
    [boolean]$fileFound = $false
	if ((test-path $finishedFilesDirectory)) 
	{
		foreach($fileName in $csvFilesToMove)                
		{		
			$destinationFileName = $fileName.FullName.Replace($exportFilesDirectory, $finishedFilesDirectory)		
			if(Test-Path $destinationFileName)
			{
				$fileFound = $true
				break
			}
		}
	}
    return $fileFound
}

############################################################################################################
# Function EnoughDiskSpaceAvailable to check if enough disk space is available on target Disk to move files#
############################################################################################################
function EnoughDiskSpaceAvailable($filesToCheck)
{   
    $driveLetter = (get-location).Drive.Name
    $volume = Get-Volume -DriveLetter $driveLetter
    return ($filesToCheck | Measure-Object -Sum Length | Select-Object Sum).Sum -lt $volume.SizeRemaining
}

################################################################################
# Function MoveExportedFiles to move finished import files to "done" directory #
################################################################################
function MoveExportedFiles($csvFilesToMove, $exportFilesDirectory ,$finishedFilesDirectory)
{   
	if (!(test-path $finishedFilesDirectory)) 
	{
		mkdir $finishedFilesDirectory
	}
	
	foreach($fileName in $csvFilesToMove)                
	{	
		$destinationFileName = $fileName.FullName.Replace($exportFilesDirectory, $finishedFilesDirectory)
		$destinationFileName = $destinationFileName.Replace('.inprogress','.csv')		
		if(Test-Path $destinationFileName)
		{
			Write-Trace "WARNING: Could not move file. The destination file already exists: $($destinationFileName)"
		}
		else
		{
			Write-Trace "Moving file $($fileName) to $($finishedFilesDirectory)"
			Move-Item -Path $fileName.FullName -Destination $destinationFileName
		}		
	}
}

################
# Main program #
################
Write-Trace "NEXTCCC-MailProperties-Export:Start"
$starttime = get-date
$timeframeendtimestamp = $starttime.AddMinutes($timeframe)
Write-Host "Starttime        : $starttime"
Write-Host "Timeframe        : $timeframe minutes"
Write-Host "Timeframe ends at: $timeframeendtimestamp"

#Load configuration file
#$configFileName   = "NEXTCCC-MailProperties-ExportConfig.xml"
try{
	Write-Trace "Loading configuration file: $($configFileName)" 
	$configFilePath = "$($PSScriptRoot)\$($configFileName)"
	[xml]$configurationFile = Get-Content $configFilePath
	Write-Trace "Configuration file loaded successfully."
}
catch [System.FileNotFoundException]
{
	LogHelper.WriteLogError("Could no load configuration file: $($configFileName) | (File not found)");
	Write-Trace "Setting DataImportStatus via EndDataImport"
	EndDataImport $SQLServer
	Write-Trace "Exit Application"
	stop-transcript | out-null
	exit 4
}

#get exportfiles directory
#$exportFilesDirectory = "$($PSScriptRoot)\$($configurationFile.Settings.ExportFilesDirectory)"
$exportFilesDirectory = $configurationFile.Settings.ExportFilesDirectory

#create dummy file for BCP faster first run 
try{
	$firstExportFileTS = (get-childitem -path $exportFilesDirectory -File -Filter "*.csv" | Select-Object -First 1).Name.Substring(31,19)
	$replacedString = "2000-01-01-00-00-00.dummy.$(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")"
	CreateDummyCSVInputFile -directory	$exportFilesDirectory -filterstring $firstExportFileTS -replacedfilterstring $replacedString
}

	catch{
		Write-Host "ERROR creating dummy file. Proceed without."
	}


#run export as long as timeframe is not exceeded
while((get-date) -lt $timeframeendtimestamp)
{

	#check if files exist in export file directory
	if($null -eq (get-childitem -path $exportFilesDirectory -File -Filter "*.csv"))
	{
		Write-Trace "No export files found in directory: $($exportFilesDirectory) - Nothing to export"
		Write-Trace "Setting DataImportStatus via EndDataImport"
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 0
	}

	#Write-Trace "Export run number $($run)"

	#get timestamp of first file in exportfiles directory
	$firstFileTimeStamp = (get-childitem -path $exportFilesDirectory -File -Filter "*.csv" | Select-Object -First 1).Name.Substring(31,19)	
	Write-Trace "Timestamp: $($firstFileTimeStamp)"
	#get all files with same timestamp
	$csvFilesToExport=@(get-childitem -path $exportFilesDirectory -File -Filter "*$firstFileTimeStamp*.csv") 
	Write-Trace "Files to export:"
	$csvFilesToExport

	Write-Trace "Check if export files already exists in FinishedFilesDirectory directory."
	#Check if export files already exists in FinishedFilesDirectory directory
	#$finishedFilesDirectory = "$($PSScriptRoot)\$($configurationFile.Settings.FinishedFilesDirectory)"
	$finishedFilesDirectory = $configurationFile.Settings.FinishedFilesDirectory
	$fileExists = FileExistsInTargetFolder -csvFilesToMove $csvFilesToExport -exportFilesDirectory $exportFilesDirectory -finishedFilesDirectory $finishedFilesDirectory
	if($fileExists)
	{
		Write-Trace "Export file(s) already exists in directory: $($finishedFilesDirectory) - Stop export"
		Write-Trace "Setting DataImportStatus via EndDataImport"
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 0
	}

	Write-Trace "Check if enough disk space is available on Disk to move files."
	#Check if enough disk space is available on Disk to move files
	$enoughSpaceAvailable = EnoughDiskSpaceAvailable -filesToCheck $csvFilesToExport
	if(!$enoughSpaceAvailable)
	{
		Write-Trace "Not enough disk space available to copy export files - Stop export"
		Write-Trace "Setting DataImportStatus via EndDataImport"
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 0
	}

	#Renaming Files to .inprogress to Lock them
	Write-Trace "Renaming Files to .inprogress to Lock them."
	try{
		$csvFilesToExport | Rename-Item -NewName {$_.Name -replace '.csv','.inprogress'} -ErrorAction Stop
		$csvFilesToExport=@(get-childitem -path $exportFilesDirectory -File -Filter "*$firstFileTimeStamp*.inprogress") 
	}
	catch
	{
		Write-Trace "Error Renaming Files"
		Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
		Write-Trace "Exception Message: $($_.Exception.Message)"
		Write-Trace "Setting DataImportStatus via EndDataImport"
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 4
	}

	#Create DataTable from export files
	[System.Data.DataTable]$importDataTable = New-Object System.Data.DataTable 'ImportDataTable'
	try{
		Write-Trace "Create DataTable from export files."                
		[System.Data.DataTable]$importDataTable = CreateImportDataTable $configFilePath $csvFilesToExport
	}  
	catch
	{
		Write-Trace "Error while creating ImportDataTable"
		Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
		Write-Trace "Exception Message: $($_.Exception.Message)"
		Write-Trace "Trying to rename inprogressFiles Back to csv"
		try{
			$csvFilesToExport | Rename-Item -NewName {$_.Name -replace '.inprogress','.csv'} -ErrorAction Stop
			Write-Trace "Sucsessfully renamed Files Back to CSV"
		}
		catch
		{
			Write-Trace "Couldnt Rename Files Back to CSV."
			Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
			Write-Trace "Exception Message: $($_.Exception.Message)"
		}
		Write-Trace "Setting DataImportStatus via EndDataImport"
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 4
	} 

	Write-Trace "InputDataTable created successfully."

	#Export data by SQLBulkCopy to destination SQL DB table
	[string]$connectionString = $configurationFile.Settings.CONNECTIONSTRING
	[string]$databaseTableName = $configurationFile.Settings.DBTableName
	try{                
		Write-Trace "Export data to destination SQL DB table."
		Write-Trace "ConnectionString: $($connectionString) | databaseTableName: $($databaseTableName)"		                            
		[boolean]$DBImportError = ExportMailProperties $connectionString $databaseTableName $importDataTable
		if($DBImportError -eq $false){
			Write-Trace "Error while export data to destination SQL DB table databaseTableName"
			Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
			Write-Trace "Exception Message: $($_.Exception.Message)"
			Write-Trace "Trying to rename inprogressFiles Back to csv"
			try{
				$csvFilesToExport | Rename-Item -NewName {$_.Name -replace '.inprogress','.csv'} -ErrorAction Stop
				Write-Trace "Sucsessfully renamed Files Back to CSV"
			}
			catch
			{
				Write-Trace "Couldnt Rename Files Back to CSV."
				Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
				Write-Trace "Exception Message: $($_.Exception.Message)"
			}
			Write-Trace "Setting DataImportStatus via EndDataImport"		
			EndDataImport $SQLServer
			Write-Trace "Exit Application"
			stop-transcript | out-null
			exit 4
		}
	}  
	catch
	{
		Write-Trace "Error while export data to destination SQL DB table databaseTableName"
		Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
		Write-Trace "Exception Message: $($_.Exception.Message)"
		Write-Trace "Trying to rename inprogressFiles Back to csv"
		try{
			$csvFilesToExport | Rename-Item -NewName {$_.Name -replace '.inprogress','.csv'} -ErrorAction Stop
			Write-Trace "Sucsessfully renamed Files Back to CSV"
		}
		catch
		{
			Write-Trace "Couldnt Rename Files Back to CSV."
			Write-Trace "Exception Type: $($_.Exception.GetType().FullName)"
			Write-Trace "Exception Message: $($_.Exception.Message)"
		}
		Write-Trace "Setting DataImportStatus via EndDataImport"
		
		EndDataImport $SQLServer
		Write-Trace "Exit Application"
		stop-transcript | out-null
		exit 4
	}   

	#Move finished export files to FinishedFiles directory
	Write-Trace "Move finished export files to FinishedFiles directory."
	MoveExportedFiles $csvFilesToExport $exportFilesDirectory $finishedFilesDirectory	
}
Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "NEXTCCC-MailProperties-Export:END"

##########################################################
# Closing
##########################################################
if ($errorfound) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	Write-Trace "Setting DataImportStatus via EndDataImport"
	EndDataImport $SQLServer
	stop-transcript | out-null
	exit 4
}
Write-Trace "Setting DataImportStatus via EndDataImport"
EndDataImport $SQLServer
stop-transcript| out-null
exit 0