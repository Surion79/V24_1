# NEXTCCCReporting
#
# Holt statistische Werte ueber ein Postfach und sendet einmal Mitternacht die Daten an das Postfach selbst
#
# Ansprechpartner: Walbaum, Sascha <sascha.walbaum@miele.com>
# Ansprechpartner: Guenther, Christian <christian.guenther@miele.com>
#
# Zukunft
#   Sammlen von "Created, LastModified, completed  Datum und Average Messung
#	Auswertung mehrer Postfaecher
#	Ausgabe in Datenbank
# Logging, Eventlog, Control-M, Monitoring

param (
	$mailboxsmtp= "test.ips-se@miele.de",
	[string]$outputcsvfile = "C:\Tasks\NEXTCCCReporting\database\NEXTCCCReporting.csv",
	[string]$transcriptpath = "C:\Tasks\NEXTCCCReporting\logs.summary\",
	[string]$smtpserver = "mail.miele.com",
	[string]$smtpfrom = "exchangeteam@miele.com", 
	#[string[]]$smtpto = @("frank.carius.ext@miele.com","christian.guenther@miele.com","sascha.walbaum@miele.com"),
	[string[]]$smtpto = @("frank.carius.ext@miele.com","test.ips-se@miele.de","alexander.schaefer.ext@miele.com"),
	$transcriptpurgedays=7,
	#[string]$exchangeuri = "https://comgtexmdb10.com.miele.net/PowerShell/"
	[string]$exchangeuri = "https://outlook.miele.com/PowerShell/"
)

set-psdebug -strict
write-verbose "NEXTCCCReporting: START"

#region Logging
if (!(test-path $transcriptpath -pathtype container)) {
	mkdir $transcriptpath
}
[string]$transcriptfile = ($transcriptpath +"NEXTCCCReporting."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
write-output "Start Transcript to " $transcriptfile 
Start-Transcript -path $transcriptfile

[string[]]$oldlogfilelist=""
get-item -path ($transcriptpath + "\NEXTCCCReporting.*.log") `
   | Where-Object {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | ForEach-Object {$oldlogfilelist+=$_.fullname}
	foreach ($oldlogfile in $oldlogfilelist) {
		if ($oldlogfile) { # only if oldlogpath is not null or empty
			if (test-path $oldlogfile) {
				write-output "  Removing Old LogFile:" $oldlogfile
				remove-item -path $oldlogfile
			}
		}
	}  
#end region Loggging

write-output " START: Checking Exchange Management Powershell"

if (!(Get-Command "Get-OrganizationConfig" -errorAction SilentlyContinue)) {
	write-output "   Loading Exchange Remote PowerShell"
	$error.removerange(0,1)  # remove last error
	#write-host "run-statusweb4:Creating Exchange Remote Session"
	$session = new-pssession `
		-ConfigurationName "Microsoft.Exchange" `
		-ConnectionUri $exchangeuri `
		-Authentication Negotiate
	#write-host "run-statusweb4:Import Exchange Remote Session Commandlets"
	import-pssession -Session $session -AllowClobber | out-null
}

#. 'C:\Program Files\Microsoft\Exchange Server\V15\bin\RemoteExchange.ps1'; Connect-ExchangeServer -auto -ClientApplication:ManagementShell
#region Exchange Powershell
#if ((Get-PSSnapin | where {$_.name -eq "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null) {
#	write-output " Loading PSSnapin Microsoft.Exchange.Management.PowerShell.E2010"
#	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
#}
write-output "  Set Exchange Scope to ViewEntireForest"
set-adserversettings -viewentireforest:$true
write-output " END: Checking Exchange Management Powershell"
#end region Exchange Powershell

write-output "  Loading NOW Date"
$now = get-date -Format "dd.MM.yy HH:mm"
#$mailbox = get-mailbox $mailboxsmtp
write-output "  Collect Mailboxfolderstatisstics for $mailboxsmtp"
get-mailboxfolderstatistics `
	-identity $mailboxsmtp `
	-IncludeOldestAndNewestItems `
| select-object @{Name="Date"; Expression = {$now}},@{Name="Mailbox"; Expression={$mailboxsmtp}},folderpath,itemsinfolder,OldestItemReceivedDate `
| Where-Object {$_.folderpath.startswith("/Inbox")} `
| export-csv -append -path $outputcsvfile -notypeinformation
write-output "  Collect Mailboxfolderstatisstics for $mailboxsmtp  DONE and appended"

write-output "  Check for Mail"

if ((get-date).hour -eq 0) {
	write-output "SendMail: Start via Server $smtpserver"
	write-output "SendMail: To $smtpto"
	send-mailmessage `
		-SmtpServer $smtpserver `
		-From $smtpfrom `
		-To $smtpto.split(",") `
		-Subject ("NEXTCCCReporting Summary") `
		-Body "See Attachment. Importing in Excel requires to use Comma as separator" `
		-Attachments ($outputcsvfile)
	write-output "SendMail: End"
}
else {
	write-output "SKIP Send Mail"
}

write-verbose "NEXTCCCReporting: Remove PSSession"
Remove-PSSession $Session

write-verbose "NEXTCCCReporting: END"
Stop-Transcript
