# NEXTCCC-MailProperties-Export.ps1
#
# Export CSV-Fields to SQL Tables using BCP
#
# 20171109 FC Initial Version
# 20180214 FC Verschieben der Error-Dateien im Fehlerfall um Reimport zu verhindern

[CMDLetBinding()]
param (
	[string]$SQLServer        = "DEGTDBCL31VPEMS.de.miele.net\PEMS" ,
	[string]$SQLDatabasetable = "email_kpi.dbo.MailProperties",
	[int]$debuglevel          = 3, 
	[int]$transcriptpurgedays = 10,   # Purge log files older than these days
	[string]$test=""     # Set to true to check Control-M Logic
)

set-psdebug -strict
$error.clear()
[boolean]$errorfound=$false

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# Import Race Modul to log activities
Import-Module .\write-trace.psm1 -force
set-TraceParameter `
	-tracefilename ".\logs.UpdateSqlData\NEXTCCC-UpdateSqlData.$(get-date -format "yyyy-MM-dd-HH-mm-ss-fff").log" `
	-levelfile 5 `
	-levelcon $debuglevel

Write-Trace "Start"
Write-Trace "Scriptname                   : $($MyInvocation.InvocationName)"
Write-Trace "Servername                   : $($env:COMPUTERNAME)"
Write-Trace "Username                     : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter SQLServer          : $SQLServer"
Write-Trace "Parameter SQLDatabasetable   : $SQLDatabasetable"
Write-Trace "Tracefile                    : $((get-traceparameter).tracefilename)"


##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#$objectRef = $host.GetType().GetField(�externalHostRef�, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetProperty�
#$consoleHost = $objectRef.GetType().GetProperty(�Value�, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(�IsStandardOutputRedirected�, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#  $field = $consoleHost.GetType().GetField(�standardOutputWriter�, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(�standardErrorWriter�, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path ".\logs.UpdateSqlData")) {mkdir ".\logs.UpdateSqlData"}
[string]$transcriptfile = (".\logs.UpdateSqlData\NEXTCCC-UpdateSqlData.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Purging old Logfile"

[string[]]$oldlogfilelist=""
get-item -path ".\logs.UpdateSqlData\NEXTCCC-UpdateSqlData.*.log" `
   | where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | %{$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-UpdateSqlData:Start"
$starttime = get-date

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=email_kpi;Integrated Security=true";
$SqlConnection.Open()
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = "sp_UpdateData"
$SqlCmd.Connection = $SqlConnection
$sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
$sqlCmd.CommandTimeout = 1200
$result = $sqlCmd.ExecuteNonQuery()
if ($result -ne 0) {
	$errorfound = $true
}
$SqlConnection.Close()

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "NEXTCCC-UpdateSqlData:END"

##########################################################
# Closing
##########################################################
if ($errorfound) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0