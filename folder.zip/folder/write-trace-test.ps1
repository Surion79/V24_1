write-host "Import"
import-module .\write-trace.psm1 -force
set-TraceParameter -filename ".\testrace.log"
set-TraceParameter -filterkeywords "Wort1 wort2 word32"
get-TraceParameter | fl
write-trace "Normal"
write-trace -level 1 -keyword "wort1" "Error"
write-trace -level 2 -keyword "wort1" "Warning"
write-trace -level 3 -keyword "wort1" "Info"
write-trace -level 4 -keyword "wort4" "Debug 4"
write-trace -level 5 -keyword "wort3" "Debug 5"
write-trace -level 5 -keyword "wort1" "Debug 5"
