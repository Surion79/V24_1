﻿param (	
	[string]$SQLServer          = "DEGTDBCL31VPEMS.de.miele.net\PEMS",
    [string]$Database           = "email_kpi",
    [string]$SpName    = "sp_ReorgData"
)

#Open SQL Connection
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=$($Database);Integrated Security=true";
$SqlConnection.Open()

#Configure SQL Command as Stored Procedure
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SpName
$SqlCmd.Connection = $SqlConnection
$sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
$sqlCmd.CommandTimeout = 130000

#Execute Command
$result = $sqlCmd.ExecuteNonQuery()

#Close SQL Connection
$SqlConnection.Close()