﻿# NEXTCCC-MakeFolder2.ps1
#
# 20171206  FC
#	Initial Version
# Optionen
#	Parallelisierung der Abfragen
# 20180116 FC Zusammenfassung der Mails
# 20180223 JD  
# 20180517 AS Encoding in der Folderpath Erstellung und send-mailmessage von UTF-8 zu Unicode geändert, da es Probleme mit französischen Sonderzeichen in Foldernamen gab. 
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),	
    [string]$ewsDllLoc        = "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll",
	[switch]$enforceall       = $false, 
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff", 
	[string]$smtpserver       = "relay.miele.com",
	[string]$smtpfrom         = "migteam@miele.com",
	[string]$test="",     # Set to true to check Control-M Logic
	[string]$exchangeuri      = "https://outlook.miele.com/PowerShell/"
)
[string]$configcsv        = "$($PSScriptRoot)\NEXTCCC-MailboxConfig.csv"

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')

##########################################################
# Helper Function to do tracing
##########################################################

Import-Module "$($PSScriptRoot)\write-trace.psm1"
set-TraceParameter `
	-tracefilename "$($PSScriptRoot)\logs.MakeFolder\NEXTCCC-MakeFolder.trace.$($jobidlog).log" `
	-levelfile 5 `
	-levelcon 8


Write-Trace "NEXTCCC-MakeFolder: Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"

##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#$objectRef = $host.GetType().GetField(“externalHostRef”, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetProperty”
#$consoleHost = $objectRef.GetType().GetProperty(“Value”, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(“IsStandardOutputRedirected”, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#  $field = $consoleHost.GetType().GetField(“standardOutputWriter”, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(“standardErrorWriter”, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path "$($PSScriptRoot)\logs.MakeFolder")) {mkdir "$($PSScriptRoot)\logs.MakeFolder"}
[string]$transcriptfile = ("$($PSScriptRoot)\logs.MakeFolder\NEXTCCC-MakeFolder.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace " Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Cleanup old Logfiles"
[string[]]$oldlogfilelist=""
get-item -path "$($PSScriptRoot)\logs.MakeFolder\NEXTCCC-MakeFolder.*.log" `
	| where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
	| %{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  Logfile $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old LogFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old LogFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old LogFile: $($oldlogfile)"
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-MakeFolder:Start"
$starttime = get-date


#############################################
# Hauptprogramm
#############################################

Write-Trace "NEXTCCC-MakeFolder: Loading EWS_DLL"
Add-Type -Path $ewsDllLoc

#Load Exchange Snapin to get mailboxes
Write-Trace "NEXTCCC-MakeFolder: Loading Exchange Snapin to get mailboxes"

##########################################################
# Loading Exchange environment
##########################################################
Write-Host "Loading Exchange Environment"
Write-Host "Creating Exchange Remote Session to $($exchangeuri)"

#Alt. not supportet https://blog.rmilne.ca/2015/01/28/directly-loading-exchange-2010-or-2013-snapin-is-not-supported/
#Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010

$session = new-pssession `
	-ConfigurationName "Microsoft.Exchange" `
	-ConnectionUri $exchangeuri `
	-Authentication negotiate
Write-Host "Import Exchange Remote Session Commandlets"
import-pssession -Session $session -AllowClobber | out-null


##########################################################
# Getting config/list of mailbox addresses
##########################################################

Write-Trace "Loading ConfigFILE from $($configcsv) START"
[object[]]$configlist = Import-Csv -path $configcsv | where {$_.active -eq "1"}
Write-Trace "Loading ConfigFILE from $($configcsv) END"

[int]$totalmailbox=0
[int]$totalfound=0
[int]$totalmissing=0
[int]$totalcreated=0
[int]$totalcreatedfail=0
[int]$totalorphaned=0
[int]$totalerror=0


foreach ($line in $configlist){
#foreach ($mailbox in $mailboxlist.keys){
	$mailbox = $line.MailboxSMTP
	Write-Trace -Level 4 "Mailbox $($mailbox)"
	$totalmailbox++
	Write-Progress `
		-Id 1 `
		-Activity "totalmailbox $($totalmailbox) of $($configlist.count)" `
		-Status "Mailbox $mailbox" `
		-PercentComplete ($totalmailbox / $configlist.count *100)

	#
	#  Check if mailbox exists
	#
	$exist = [bool](Get-mailbox $mailbox -erroraction SilentlyContinue)
	
	if (!$exist){
		continue
	}
	
	# 
	#  Connect to Exchange using EWS with Impersonation
	#
	Write-Trace -level 3 " Initializing EWS"
    $ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
    $ewsservice = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
    $ewsservice.UseDefaultCredentials = $true
	$ewsservice.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$mailbox); 
	Write-Trace " Try Autodiscover for $($mailbox)"
	try {
		#$ewsservice.TraceEnabled = $true
		$ewsservice.AutodiscoverUrl($mailbox,{$true})
		#$ewsservice.TraceEnabled = $false
		Write-Trace "  AutoD Success $($ewsservice.Url)"
	}
	catch {
		write-warning " Unable to get Autodiscover entry"
		$error
		$totalerror++
		#$error.clear()
	}
	
	if ($ewsservice.url) {
		Write-Trace -Level 4 "    EWS Service established to $($ewsservice.url)"
		
		Write-Trace -Level 4 "    Loading Folder template File $($line.templatefile)"
		$folderlist = import-csv "$($PSScriptRoot)\$($line.templatefile)" | ?{$_.Folderpath}

		$rootfolderid = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::inbox)   
		$rootfolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($ewsservice,$rootfolderid)
		[string]$inboxname = $rootfolder.Displayname
		Write-Trace -Level 5 "Inboxname: $($inboxname)"
		$FolderView = new-object Microsoft.Exchange.WebServices.Data.FolderView(1000) 
		$FolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep;  

		$PropertySet = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
		$PR_Folder_Path = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(26293, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::String);  
		$PropertySet.Add($PR_Folder_Path);  
		$FolderView.PropertySet = $PropertySet;  

		$PR_FOLDER_TYPE = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(13825,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer); 
		$SearchFilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo($PR_FOLDER_TYPE,"1")  
		$SearchResult = $null  

		[hashtable]$allfolders=@{}
		[hashtable]$allsimplefolders=@{}

		$allfolders[("\"+$inboxname)]= ($rootfolder | select id,orphaned,folderfullname,duplicatesimple)
		$allfolders[("\"+$inboxname)].orphaned = $false
		$allfolders[("\"+$inboxname)].folderfullname = ("\"+$inboxname)
		$allfolders[("\"+$inboxname)].duplicatesimple=$false
		
		write-trace -level 0 "Start Collecting Folders"
		do {  
			$SearchResult = $ewsservice.FindFolders($rootfolderid,$SearchFilter,$FolderView)  
			foreach($Folder in $SearchResult.Folders){  
				write-trace -level 5 "Processing  : $($Folder.displayName)"
				write-trace -level 5 "  ItemCount : $($Folder.TotalCount)"
				$foldpathval = $null  
				#Try to get the FolderPath Value and then covert it to a usable String   
				if ($Folder.TryGetProperty($PR_Folder_Path,[ref] $foldpathval))  {  					
					###Changed from UTF8 to Unicode for special characters - french language###					
					$binarray = [Text.Encoding]::Unicode.GetBytes($foldpathval)  
					$hexArr = $binarray | ForEach-Object { $_.ToString("X2") }
					$hexString = $hexArr -join ''  
					###Replace is never used###
					#$hexString = $hexString.Replace("FEFF", "5C00")  
					# convert path to string
					[string]$Folderpath = ""  
					###Change incrementation from +2 to +4 due to encoding change from UTF-8 to Unicode###
					for ($clInt=0;$clInt -lt $hexString.length;$clInt+=4){  
							$Folderpath = $Folderpath + [Convert]::ToString([Convert]::ToChar([Convert]::ToInt32($hexString.Substring($clInt,2),16)))  							
					}
				}  
				write-trace -level 5 "  Folderpath: $($Folderpath)"
				[int]$folderlevel = $Folderpath.split("\").count
				write-trace -level 5 " Folderlevel: $folderlevel"
				$allfolders[$Folderpath]= ($folder | select id,orphaned,folderfullname,duplicatesimple)
				$allfolders[$Folderpath].orphaned = $true
				$allfolders[$Folderpath].duplicatesimple = $false
				$allfolders[$Folderpath].folderfullname = $Folderpath

				[string]$simplefoldername=""
				$splitsimplefoldername = $Folderpath.split("\")
				if ($splitsimplefoldername[2] -match "^(\d\d_\d\d)? .+$" -or $splitsimplefoldername[2] -match "^(\d\d)(_\d\d)? .+$") {
					write-trace -level 5 " SimpleName: Match Level 1"
					$simplefoldername = $matches[1]
					
					if ($splitsimplefoldername.count -ge 4) {
						if ($splitsimplefoldername[3] -match "^(\d\d_\d\d) .+$" ) {
							write-trace -level 5 " SimpleName: Match Level 2"
							$simplefoldername = $simplefoldername + "\" + $matches[1]
						}
						else {
							write-trace -level 5 " SimpleName: NoMatch Level 2"
							$simplefoldername = ""
						}
					}
					else {
						write-trace -level 5 " SimpleName: No Level 2"
					}
				}
				else {
					write-trace -level 5 " SimpleNameNo: Match Level 1"
				}
				
				
				if ($simplefoldername -eq "") {
					write-trace -level 5 "  SimpleName: NoMatch" 
				}
				else {
					write-trace -level 5 " SimpleName: $($simplefoldername)"
					if (($folderlevel -eq 3) -and ($allsimplefolders[$simplefoldername])){
						write-trace -level 4 "Duplicate Simple Folder"
						write-host "Duplicate Simple Folder with $($allsimplefolders[$simplefoldername].folderpath)" -backgroundcolor yellow -foregroundcolor black
						$allfolders[$Folderpath].duplicatesimple = $true
						$allfolders[$allsimplefolders[$simplefoldername].folderpath].duplicatesimple=$true
					}
					else {
						$allsimplefolders[$simplefoldername]= ("" | select folderpath,folderfullname,orphaned)
						$allsimplefolders[$simplefoldername].folderpath = $Folderpath
						$allsimplefolders[$simplefoldername].orphaned = $true
						$allsimplefolders[$simplefoldername].folderfullname = $Folderpath
					}
				}
			} 
			$FolderView.Offset += $SearchResult.Folders.Count 
		}while($SearchResult.MoreAvailable -eq $true)  

		#debug ausgabe 
		$allfolders | ft -AutoSize
		
		$allsimplefolders | ft -AutoSize

		Write-Trace -level 3 "Processing folder list for matches, missing and orphaned"
		
		foreach ($entry in $folderlist){
			write-trace -level 4 "Checking $($entry.folderpath)"
			[string]$fullfoldername = "\" + $inboxname + $entry.folderpath
			write-trace -level 4 "  Full  $($fullfoldername)"
			# Simple Folder name erstellen
			[string]$simplefoldername=$null
			if ($fullfoldername -match "^\\.*\\(\d\d) .*\\(\d\d_\d\d) .*$") {
				[string]$simplefoldername = $matches[1] + "\" + $matches[2]
				write-trace -level 5 "  Simple1  $($simplefoldername)"
			}
			elseif ($fullfoldername -match "^\\.*\\(\d\d) .*\\(\d\d) .*$") {
				[string]$simplefoldername = $matches[1] + "\" + $matches[2]
				write-trace -level 5 "  Simple2  $($simplefoldername)"
			}
			elseif ($fullfoldername -match "^\\.*\\(\d\d_\d\d) .*$") {
				[string]$simplefoldername = $matches[1]
				write-trace -level 5 "  Simple3  $($simplefoldername)"
			}
			elseif ($fullfoldername -match "^\\.*\\(\d\d) .*$") {
				[string]$simplefoldername = $matches[1]
				write-trace -level 5 "  Simple4  $($simplefoldername)"
			}
			else {
				write-trace -level 5 "  No SimpleName $($fullfoldername)"
			}

			if ($allfolders.containskey($fullfoldername)){
				write-trace -level 5 "FullFolder exists -Skip"
				$totalfound++
				$allfolders[$fullfoldername].orphaned = $false
				#if ($simplefoldername) {
				#	$allsimplefolders[$simplefoldername].orphaned = $false
				#}
			}
			elseif ($allsimplefolders[$simplefoldername] -and $simplefoldername){
				write-trace -level 5 "Simple Folder $($simplefoldername) exists -Skip"
				$totalfound++
				$allsimplefolders[$simplefoldername].orphaned = $false
				$allfolders[($allsimplefolders[$simplefoldername].folderfullname)].orphaned = $false
			}
			
			elseif (!$allsimplefolders.contains($simplefoldername)) {
			#else {
				write-trace -level 5 "Folder Missing - calculate parent folder"
				$totalmissing++
				if (($entry.enforce -eq "1") -or $enforceall) {
					write-trace -level 4 "Add Folder $($fullfoldername)"
					$fldArray=$fullfoldername.split("\")
					$parentfoldername = [string](($fldArray[0..($fldArray.Length-2)]) -join "\")
					write-trace -level 5 "parent folder = $($parentfoldername) "
					$shortfoldername = $fldArray[($fldArray.Length-1)]
					write-trace -level 5 "shortfoldername = $($shortfoldername) "
					$NewFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($ewsservice) 
					$NewFolder.DisplayName = $shortfoldername
					$NewFolder.FolderClass = "IPF.Note"
					$error.clear()
					write-host "  Create Folder $($fullfoldername)" -backgroundcolor blue -foregroundcolor white
					$NewFolder.Save($allfolders[$parentfoldername].Id)
					if ($error) {
						$error.clear()
						write-trace -level 6 " Error: Unable to create Folder"
						$totalcreatedfail++
						if ($line.notifySMTP -ne "") {
							write-trace -level 6 " Error: Send Mail to $($line.notifySMTP)"
							send-mailmessage `
								-smtpServer $smtpserver	`
								-from $smtpfrom `
								-to $line.notifySMTP.split(",") `
								-subject "NextCCC-MakeFolder: Unable to create Folder $($Mailbox)::$($shortfoldername)" `
								-body 	("NextCCC-MakeFolder: Unable to create Folder $($Mailbox)::$($shortfoldername)`r`n "+ `
										"Mailbox          $($Mailbox) `r`n "+ `
										"FolderPath       $($fullfoldername)`r`n "+ `
										"Parentfoldername $($parentfoldername)`r`n "+ `
										"Subfolder        $($shortfoldername) `r`n " + `
										"Check if parent folder exists and add folder path to template to create all missing folders `r`n ") `
								-encoding ([System.Text.Encoding]::Unicode)
						}
					}
					else {
						write-trace -level 6 " Success: Folder created"
						$totalcreated++
						if ($line.notifySMTP -ne "") {
							write-trace -level 6 " Send Mail to $($line.notifySMTP)"
							send-mailmessage `
								-smtpServer $smtpserver	`
								-from $smtpfrom `
								-to $line.notifySMTP.split(",") `
								-subject "NextCCC-MakeFolder: Folder Created $($Mailbox)::$($shortfoldername)" `
								-body 	("NextCCC-MakeFolder: Folder Created $($Mailbox)::$($shortfoldername)`r`n "+ `
										"Mailbox          $($Mailbox) `r`n "+ `
										"FolderPath       $($fullfoldername)`r`n "+ `
										"parentfoldername $($parentfoldername)`r`n "+ `
										"Subfolder        $($shortfoldername) `r`n ") `
								-encoding ([System.Text.Encoding]::Unicode)
						}
					}
					$allfolders[$fullfoldername]= ($folder | select id,folderfullname,orphaned)
					$allfolders[$fullfoldername].folderfullname = $fullfoldername
					$allfolders[$fullfoldername].orphaned = $false
				}
				else {
					write-trace -level 4 "Report Missing Folder and stop processing of that line"
					$totalmissing++
					if ($line.notifySMTP -ne "") {
						write-trace -level 6 " Send Mail to $($line.notifySMTP)"
						send-mailmessage `
							-smtpServer $smtpserver	`
							-from $smtpfrom `
							-to $line.notifySMTP.split(",") `
							-subject "NextCCC-MakeFolder: Folder missing and not enforced $($Mailbox)::$($shortfoldername)" `
							-body 	("NextCCC-MakeFolder: Folder missing and not enforced $($Mailbox)::$($shortfoldername)`r`n "+ `
									"Mailbox          $($Mailbox) `r`n "+ `
									"FolderPath       $($entry.FolderPath)`r`n "+ `
									"parentfoldername $($parentfoldername)`r`n "+ `
									"Subfolder        $($entry.foldername) `r`n ") `
							-encoding ([System.Text.Encoding]::Unicode)
					}
				}
			}
			elseif ($allfolders[$allsimplefolders[$simplefoldername].folderpath].duplicatesimple) {
				write-trace -level 5 "Simple Folder $($simplefoldername) Duplicate -Skip"
			}
			else {
				write-trace -level 5 "Simple Folder $($simplefoldername) - Don't know what to do."
			}
		}
		#debugausgabe
		#$allfolders
		
		if ($line.reportadditionalfolders){
			write-trace -level 3 "Start Report of orphaned folders"
			[string]$orphanedfolderlist = (($allfolders.values | ?{$_.orphaned} | select folderfullname -expandproperty folderfullname) -join " `r`n ")
			$totalorphaned += (($allfolders.values | ?{$_.orphaned}).count)
			if ($orphanedfolderlist) {
				if ($line.notifySMTP -ne "") {
					write-trace -level 6 " Send Mail to $($line.notifySMTP)"
					send-mailmessage `
						-smtpServer $smtpserver	`
						-from $smtpfrom `
						-to $line.notifySMTP.split(",") `
						-subject "NextCCC-MakeFolder: Folder orphaned in $($Mailbox)::$($shortfoldername)" `
						-body 	("NextCCC-MakeFolder: Folder orphaned in $($Mailbox)::$($shortfoldername)`r`n "+ `
								"Mailbox          $($Mailbox) `r`n "+ `
								"Folderlist: $($entry.foldername) `r`n "+ `
								$orphanedfolderlist) `
						-encoding ([System.Text.Encoding]::Unicode)
				}
				else {
					write-trace -level 6 " Orphaned Folders folders found but no mail address "
				}
			}
			else {
				write-trace -level 6 " No Orphaned Folders - skip."
			}
		}
		
		[string]$duplicatesimplefolderlist = ""
		[string]$duplicatesimplefolderlist = (($allfolders.values | ?{$_.duplicatesimple} | select folderfullname -expandproperty folderfullname | Sort-Object folderfullname) -join " `r`n ")
			##$totalduplicatesimple += (($allfolders.values | ?{$_.duplicatesimple}).count)
			#if ($totalduplicatesimple) {
			if ($duplicatesimplefolderlist -ne "") {
				if ($line.notifySMTP -ne "") {
					write-trace -level 6 " Send Mail to $($line.notifySMTP)"
					send-mailmessage `
						-smtpServer $smtpserver	`
						-from $smtpfrom `
						-to $line.notifySMTP.split(",") `
						-subject "NextCCC-MakeFolder: Folder duplicatesimple in $($Mailbox)::$($shortfoldername)" `
						-body 	("NextCCC-MakeFolder: Folder duplicatesimple in $($Mailbox)::$($shortfoldername)`r`n "+ `
								"Mailbox          $($Mailbox) `r`n "+ `
								"Folderlist: $($entry.foldername) `r`n "+ `
								$duplicatesimplefolderlist) `
						-encoding ([System.Text.Encoding]::Unicode)
				}
				else {
					write-trace -level 6 " duplicatesimple Folders folders found but no mail address "
				}
			}
			else {
				write-trace -level 6 " No duplicatesimple Folders - skip."
			}
		
		
		
	}
	else {
		Write-Warning "    No EWS Service Available"
		Write-Trace -Level 4 "    No EWS Service Found"
		[int]$totalerror++
	}
}

Write-Trace "Total mailbox         $($totalmailbox)"
Write-Trace "Total found           $($totalfound)"
Write-Trace "Total missing         $($totalmissing)"
Write-Trace "Total created         $($totalcreated)"
Write-Trace "Total createfail      $($totalcreatedfail)"
Write-Trace "Total totalorphaned   $($totalorphaned)"
Write-Trace "Total totaldupesimple $($totalduplicatesimple)"
Write-Trace "Total error   $($totalerror)"
Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0
Write-Trace "NEXTCCC-MakeFolder: Start"