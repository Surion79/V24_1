##########################################################
# Define Functions for processing folders/mails 
##########################################################
function ConvertToString($ipInputString){
    $Val1Text = ""
    for ($clInt=0;$clInt -lt $ipInputString.length;$clInt++){  
		$Val1Text = $Val1Text + [Convert]::ToString([Convert]::ToChar([Convert]::ToInt32($ipInputString.Substring($clInt,2),16)))  
		$clInt++  
	}  
	return $Val1Text  
}  

#maximum length of columns in SQL
$maxLengthJobId = 50
$maxLengthMessageId = 200
$maxLengthInternetMessageId = 300
$maxLengthSender = 200
$maxLengthMailBoxName = 200
$maxLengthFlagStatus = 20
$maxLengthFolderPath = 200
$maxLengthFolderId = 10
$maxLengthFolderName = 200
$maxLengthCategories = 200

#function to to ensure string length to maximum value 
function Ensure-MaxLength {

	param (
		[string]$stringToCheck,
		[int]$maxLength
	)
	
	if($stringToCheck.Length -gt $maxLength)
	{
		$stringToCheck = $stringToCheck.Substring(0,$maxLength)
	}

	$stringToCheck
}

# 
# Bind EWS to given Mailbox and start from Inbox
#
function Process-Mailbox{
	param (
		[string]$mailAddress   # SMTP_Adresse des Postfachs
	)
	Write-Trace "Process-Mailbox: Start"
	$global:mailCount = 0
	Write-Trace " Initializing EWS"
    $ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
    ## Create Exchange Service Object
    $service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
        
    $service.UseDefaultCredentials = $true
	$service.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$mailAddress ); 

	Write-Trace " Try Autodiscover for $($mailAddress)"
	try {
		#$service.TraceEnabled = $true
		$service.AutodiscoverUrl($mailAddress,{$true})
		#$service.TraceEnabled = $false
	}
	catch {
		write-warning " Unable to get Autodiscover entry"
	}
	$error.clear()
	if ($service.Url -ne $null){
		Write-Trace "  Prepare Folder Search"
			
		#"Checking : " + $mailAddress  
		#Define Extended propserties  
		$PR_FOLDER_TYPE = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(13825,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);  
		$folderidcnt = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox) 
		
		
		# Compile PropertySet of Folders to load
		$psPropertySet = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
		$PR_MESSAGE_SIZE_EXTENDED = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(3592,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Long); 
		#$PR_DELETED_MESSAGE_SIZE_EXTENDED = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(26267,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Long);  
		$PR_Folder_Path = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(26293, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::String);  
		#Add Properties to the  Property Set  
		$psPropertySet.Add($PR_MESSAGE_SIZE_EXTENDED); 
		$psPropertySet.Add($PR_Folder_Path);  

		#Define the FolderView used for Export should not be any larger then 1000 folders due to throttling  
		$fvFolderView =  New-Object Microsoft.Exchange.WebServices.Data.FolderView(1000)  
		#Deep Transval will ensure all folders in the search path are returned  
		$fvFolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep;  
		$fvFolderView.PropertySet = $psPropertySet; 
		
		#The Search filter will exclude any Search Folders  
		$sfSearchFilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo($PR_FOLDER_TYPE,"1")  
		$fiResult = $null  
		
		$Inbox = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$folderidcnt)  

		Write-Trace "Process-Mailbox:  Collect all valid Folders" #7
		[hashtable]$folderlist = @{}
		$folderlist["\Inbox"]= $Inbox  # preload Inbox as base folder
		Write-Trace " FullFoldername   ADD   \Inbox"
		#The Do loop will handle any paging that is required if there are more the 1000 folders in a mailbox
		do {  
			$fiResult = $service.FindFolders($folderidcnt,$sfSearchFilter,$fvFolderView)  
			foreach($ffFolder in $fiResult.Folders){  
				$foldpathval = $null  
				#Try to get the FolderPath Value and then covert it to a usable String   
				if ($ffFolder.TryGetProperty($PR_Folder_Path,[ref] $foldpathval))  
				{  
					<# $binarry = [Text.Encoding]::UTF8.GetBytes($foldpathval)  
					$hexArr = $binarry | ForEach-Object { $_.ToString("X2") }  
					$hexString = $hexArr -join ''  
					$hexString = $hexString.Replace("FEFF", "5C00")  
					$fullfoldername = ConvertToString($hexString) #>  
					$fullfoldername = $foldpathval
				}  
				
				
				[boolean]$matchfolder=$false
				$splitsimplefoldername = $fullfoldername.split("\")
				if ($splitsimplefoldername[2] -match "^(\d\d)(_\d\d)? .+$" ) {
					#write-trace -level 5 " SimpleName: Match Level 1"
					$matchfolder=$true
					if ($splitsimplefoldername.count -ge 4) {
						if ($splitsimplefoldername[3] -match "^(\d\d_\d\d) .+$" ) {
							#write-trace -level 5 " SimpleName: Match Level 2"
						}
						else {
							#write-trace -level 5 " SimpleName: NoMatch Level 2"
							$matchfolder=$false
						}
					}
					else {
						#write-trace -level 5 " SimpleName: No Level 2"
					}
				}
				else {
					#write-trace -level 5 " SimpleNameNo: Match Level 1"
				}
				
				if ($matchfolder) {
					Write-Trace " FullFoldername   MATCH $($fullfoldername)"
					$folderlist[$fullfoldername]= $ffFolder
				}
				else {
					Write-Trace " FullFoldername NOMATCH $($fullfoldername)"
				}
			}
			$fvFolderView.Offset += $fiResult.Folders.Count 
		} while($fiResult.MoreAvailable -eq $true)  

		$folderCount = 0;
		if ($folderlist) {
			Write-Trace " Start processing Folders in Mailbox"
			foreach ($folder in $folderlist.keys){
				$folderCount++
				Write-Progress `
					-Id 2 `
					-ParentId 1 `
					-Activity "Mailfoldercount $($folderCount) of $($folderlist.count)" `
					-Status "Mailfolder $($folder)" `
					-PercentComplete ($folderCount / ($folderlist.count) *100)
				Process-Folder $folderlist[$folder] $mailAddress $fullfoldername $folder
			}
		}
		else {
			Write-Trace " No Folders in Mailbox found"
		}
	}
	Write-Trace "Process-Mailbox: Processed mails: $($global:mailCount)"
	Write-Trace "Process-Mailbox: End"
}

function Process-Folder {
	param ( 
		$folderItem, 
		[string]$mailAddress, 
		[string]$fullfoldername,
		[string]$folder
	)
	
	Write-Trace "Process-Folder: Start" #8
	Write-Trace "  FolderDisplayName : $($folderItem.displayName)" #8
	Write-Trace "  TotalItemCount    : $($folderItem.TotalCount)"  #8
	Write-Trace "  folder            : $($folder)"
	$folderId = $folderItem.DisplayName
	if ($folder -eq "\Inbox"){
		$folderId = "00";
		$fpath = "\$($folderItem.DisplayName)"
	}
	else{
		$pos = $folderItem.DisplayName.IndexOf(" ")
		if ($pos -gt 0){
			$folderId = $folderItem.DisplayName.Substring(0, $pos)
		}
		else{
			if ($folderItem.DisplayName.Length -gt 5){
				$folderId = $folderItem.DisplayName.Remove(5)
			}
		}
	}
	Write-Trace "  FolderId          : $($folderId)" #8
	
	if ($folderId -ne "00"){
		$FolderSize = $null;  
		$FolderSizeValue = 0  
		#Try to Get the FolderSize Value and output it to the $FolderSize varible  
		if ($folderItem.TryGetProperty($PR_MESSAGE_SIZE_EXTENDED,[ref] $FolderSize)) {  
			$FolderSizeValue = [Int64]$FolderSize  
		}  
		$foldpathval = $null  
		#Try to get the FolderPath Value and then covert it to a usable String   
		if ($folderItem.TryGetProperty($PR_Folder_Path,[ref] $foldpathval)) {  
			<# $binarry = [Text.Encoding]::UTF8.GetBytes($foldpathval)  
			$hexArr = $binarry | ForEach-Object { $_.ToString("X2") }  
			$hexString = $hexArr -join ''  
			$hexString = $hexString.Replace("FEFF", "5C00")  
			$fpath = ConvertToString($hexString) #>  
			$fpath =$foldpathval
		}  
	}
	
	#Process-MailsInFolder $folderItem $fullfoldername $mailAddress
	Process-MailsInFolder $folderItem $fpath $mailAddress $folderId
	Write-Trace "Process-Folder: End" #8
}

function Process-MailsInFolder{
	param (
		$folderItem, 
		[string]$fpath, 
		[string]$mailAddress,
		[string]$folderId
	)
	
	Write-Trace "Process-MailsInFolder: Start" #9
	#Write-Trace "Process-MailsInFolder: fpath $($fpath)"
	[long]$pageSize = 5
	[long]$offset = 0

	#$PidTagSubject = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x0037,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::String)
	$PidTagFlagStatus = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x1090, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer)
	$PidTagFlagCompleteTime = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x1091, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
	$propertySet = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
	#$propertySet.Add($PidTagSubject)
	$propertySet.Add($PidTagFlagStatus)	
	$propertySet.Add($PidTagFlagCompleteTime)
	$ivItemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView(($pageSize+1),$offset)
	$ivItemView.Traversal = [Microsoft.Exchange.WebServices.Data.ItemTraversal]::Shallow
	$ivItemView.PropertySet = $propertySet
	#view.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Descending);
	
	#$ivsearchfilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsGreaterThan([Microsoft.Exchange.WebServices.Data.ItemSchema]::LastModifiedTime,[system.DateTime]::Now.AddDays(-1))
	[long]$i = 0

	do {
		$findItemsResults = $folderItem.FindItems($ivItemView)
		#$findItemsResults = $folderItem.FindItems($ivsearchfilter,$ivItemView)   # enable Search by date
		
		foreach($miMailItem in $findItemsResults.Items) {
			$i++   
			$perc = $i / $findItemsResults.TotalCount *100
			if ($perc -gt 100) {
				$perc = 100
			}
			if ($perc -lt 0) {
				$perc = 0
			}
			if ($perc -eq $null) {
				$perc = 0
			}
			Write-Progress `
				-ParentId 2 `
				-Id 3 `
				-Activity "Mailcount $($i) of $($findItemsResults.TotalCount)" `
				-Status "Mailsubject $($miMailItem.subject)" `
				-PercentComplete ($perc)
			$global:mailCount += 1			
			Process-Mail $miMailItem $i $folderItem $fpath $mailAddress $folderId
		}

		if ($findItemsResults.MoreAvailable -eq $true) {
			$ivItemView.Offset += $pageSize;
		}
	}
	while($findItemsResults.MoreAvailable -eq $true)# -and $i -lt 5)  
	Write-Trace "Process-MailsInFolder: Processed $($i) mails"
	Write-Trace "Process-MailsInFolder: End" #9
}

# Process individual mail and send result to STDOUT
function Process-Mail {
	param (
		$mailItem, 
		$a, 
		$folderItem, 
		$fpath, 
		$mailAddress,
		[string]$folderId
	)

	Write-Trace "Process-Mail: Start" 10
	$mailSender = "empty"
	$cpldTimeValObj = $null
	[string]$cpldTimeVal = ""
	#$DateTimeCreated = $mailItem.DateTimeCreated
	#$DateTimeSent = $mailItem.DateTimeSent
	$Categories = $mailItem.Categories
	#$LastModName = $mailItem.LastModifiedName
	#$FlagCompleteDateTime = $mailItem.Flag.CompleteDate
	#$FlagDueDateTime = $mailItem.Flag.DueDate
	$FlagStatus = [Microsoft.Exchange.WebServices.Data.ItemFlagStatus] $mailItem.Flag.FlagStatus
	$FlagStatusValue = $FlagStatus.ToString() #$FlagStatus.value__
	$cpldTimeValObj = [DateTime]0
	if ($mailItem.TryGetProperty($PidTagFlagCompleteTime, [ref] $cpldTimeValObj)) {
		$cpldTimeVal = $cpldTimeValObj.tostring($timeformat)
	}
	$CategoriesEnum = ""
	$CategoriesEnum = ($Categories -join ";")

#	$folderId = $folderItem.DisplayName
#	Write-Trace "Process-Mail: FolderId $($folderId)" 10
	#$mailSubject = $mailItem.Subject
	#if($mailItem.Subject.Length -gt 200){
	#    $mailSubject = $mailItem.Subject.Remove(200)
	#}

	#if ($folderId -eq "Inbox"){
	#	$folderId = "00";
	#}
	#else{
#		$pos = $folderItem.DisplayName.IndexOf(" ")
#		if ($pos -gt 0){
#			$folderId = $folderItem.DisplayName.Substring(0, $pos)
#		}
#		else{
#			if ($folderItem.DisplayName.Length -gt 5){
#				$folderId = $folderItem.DisplayName.Remove(5)
#			}
#		}
#	}
#	if($folderId.Length -gt 5){
#		$folderId = $folderId.Remove(5)
#	}
#	Write-Trace "Process-Mail: FolderId2 $($folderId)" #10
#	Write-Trace "Process-Mail: FPath     $($fpath)" #10
	
	$mailSender = $mailItem.Sender.Address
	if($mailItem.Sender.Address -eq $null){
		$mailSender = 'empty'
	}

	$flagStartDateTime = $mailItem.Flag.StartDate.ToString($timeformat)
	#write-host "flagStartDateTime $($flagStartDateTime)"
	if (($flagStartDateTime -eq 0) -or ($flagStartDateTime  -eq "0001-01-01 12:00:00.000") -or  ($flagStartDateTime  -eq "0001-01-01 00:00:00.000")){
		$flagStartDateTime = ""
	}

	$InternetMessageID = $mailItem.InternetMessageID
	if($InternetMessageID -eq $null){
		$mailSender = 'empty'
	}
	Write-Trace "Process-Mail: InternetMessageID 0 $($InternetMessageID)" 10

	#Check if value is not too long for SQL columns
	$jobid = Ensure-MaxLength $jobid $maxLengthJobId
	$mailItemId = Ensure-MaxLength $mailItem.Id $maxLengthMessageId
	$InternetMessageID = Ensure-MaxLength $InternetMessageID $maxLengthInternetMessageId
	$mailSender = Ensure-MaxLength $mailSender $maxLengthSender
	$mailAddress = Ensure-MaxLength $mailAddress $maxLengthMailBoxName
	$FlagStatusValue = Ensure-MaxLength $FlagStatusValue $maxLengthFlagStatus
	$FolderPath = Ensure-MaxLength FolderPath $maxLengthFolderPath
	$folderId = Ensure-MaxLength $folderId $maxLengthFolderId
	$folderItemDisplayName = Ensure-MaxLength $folderItem.DisplayName $maxLengthFolderName
	$CategoriesEnum = Ensure-MaxLength $CategoriesEnum $maxLengthCategories
	
	$newRow = New-Object PSObject -Property @{
		JobId = $jobid
		MessageId = $mailItemId
		InternetMessageID = $InternetMessageID 
		MailboxName = $mailAddress
		FolderPath = $fpath
		FolderName = $folderItemDisplayName
		FolderID = $folderId
		Sender = $mailSender
		#MessageSubject = $mailSubject
		ReceivedDateTime = $mailItem.DateTimeReceived.ToString($timeformat)
		FlagStatus = $FlagStatusValue
		FlagCompletedDateTime = $cpldTimeVal
		FlagStartDateTime = $flagStartDateTime
		LastModifiedDateTime = $mailItem.LastModifiedTime.ToString($timeformat)
		Categories = $CategoriesEnum
    }

	# Send Result to STDOU for further processing
	
	
	
	if ((get-Date $newRow.ReceivedDateTime) -gt (get-Date $earliestReceivedDateTime)){
		$newRow
	}
    # only for debugging purposes
    #if ($newRow -eq $null){
    #    write-host('Error')
    #    write-host('Counter = ' + $a)
    #    write-host('MailId = ' + $mailItem.Id)
    #    write-host('Mailbox = ' + $mailAddress)
    #    write-host('FolderPath = ' + $fpath)
    #    write-host('FolderName = ' + $folderItem.DisplayName)
    #    write-host('FolderID = ' + $folderId)
    #    write-host('Sender = ' + $mailSender)
    #    write-host('Subject = ' + $mailSubject)
    #    write-host('RcvdDT = ' + $mailItem.DateTimeReceived.ToString())
    #    write-host('FlagStatusVal = ' + $FlagStatusValue)
    #    write-host('FlagCompletedDateTime = ' + $cpldTimeVal.ToString())
    #    write-host('FlagStartDateTime = ' + $mailItem.Flag.StartDate.ToString())
    #    write-host('LastModifiedDateTime = ' + $mailItem.LastModifiedTime.ToString())
    #    write-host('Categories = ' + $CategoriesEnum)
    #}
	Write-Trace "Process-Mail: End" 10
}

################################################################################
# Function to check if the stored procedure "sp_GetReorgDataStatus" is running #
################################################################################

function IsStoredProcedureRunning([string]$SPName)
{
    [string]$SQLServer      = "DEGTDBCL31VPEMS.de.miele.net\PEMS"
    [string]$Database       = "email_kpi"
    [string]$ParameterName  = "@IsRunning"
    [string]$ParameterType  = "Int16"

    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=$($Database);Integrated Security=true";
    $SqlConnection.Open()
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
    $SqlCmd.CommandText = $SPName
    $SqlCmd.Connection = $SqlConnection
    $sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
    $sqlCmd.CommandTimeout = 1200
    $outParameter = new-object System.Data.SqlClient.SqlParameter;
    $outParameter.ParameterName = $ParameterName;
    $outParameter.Direction = [System.Data.ParameterDirection]'Output';
    $outParameter.DbType = [System.Data.DbType]$ParameterType;
    $outParameter.Size = 2500;
	$SqlCmd.Parameters.Add($outParameter) >> $null;    
	$result = $sqlCmd.ExecuteNonQuery()	
    $isRunning = $SqlCmd.Parameters[$ParameterName].Value;
	$SqlConnection.Close()
	    
    if ($isRunning -eq 0) {        
        return $false    
    } else {        
        return $true
    }    
}

#Load EWS_DLL"
Add-Type -Path "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"

[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff"
$earliestReceivedDateTime = "2018-01-01 00:00:00.001" # only take into account the mails, which are received after this date