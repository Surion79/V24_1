# NEXTCCC-MailProperties-Export.ps1
#
# Export CSV-Fields to SQL Tables using BCP
#
# 20171109 FC Initial Version
# 20180214 FC Verschieben der Error-Dateien im Fehlerfall um Reimport zu verhindern
# 20180605 AS Prüfung ob Stored Procedure ReorgData läuft mittels IsReorgDataRunning Funktion, 
#				die im Modul NEXTCCC-MailPropertiesFunctionsModule.ps1 definiert ist

[CMDLetBinding()]
param (
	[string]$SQLServer        = "DEGTDBCL31VPEMS.de.miele.net\PEMS" ,
	[string]$SQLDatabasetable = "email_kpi.dbo.MailProperties",
	[int]$debuglevel          = 3, 
	[int]$transcriptpurgedays = 10,   # Purge log files older than these days
	[string]$test=""     # Set to true to check Control-M Logic
)

set-psdebug -strict
$error.clear()
[boolean]$errorfound=$false

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# Import Race Modul to log activities
Import-Module "$($PSScriptRoot)\write-trace.psm1" -force
set-TraceParameter `
	-tracefilename "$($PSScriptRoot)\logs.UpdateSqlDataMailProperties\NEXTCCC-UpdateSqlDataMailProperties.$(get-date -format "yyyy-MM-dd-HH-mm-ss-fff").log" `
	-levelfile 5 `
	-levelcon $debuglevel

Write-Trace "Start"
Write-Trace "Scriptname                   : $($MyInvocation.InvocationName)"
Write-Trace "Servername                   : $($env:COMPUTERNAME)"
Write-Trace "Username                     : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter SQLServer          : $SQLServer"
Write-Trace "Parameter SQLDatabasetable   : $SQLDatabasetable"
Write-Trace "Tracefile                    : $((get-traceparameter).tracefilename)"


##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#$objectRef = $host.GetType().GetField(�externalHostRef�, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetProperty�
#$consoleHost = $objectRef.GetType().GetProperty(�Value�, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(�IsStandardOutputRedirected�, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#  $field = $consoleHost.GetType().GetField(�standardOutputWriter�, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(�standardErrorWriter�, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path "$($PSScriptRoot)\logs.UpdateSqlDataMailProperties")) {mkdir "$($PSScriptRoot)\logs.UpdateSqlDataMailProperties"}
[string]$transcriptfile = ("$($PSScriptRoot)\logs.UpdateSqlDataMailProperties\NEXTCCC-UpdateSqlDataMailProperties.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Purging old Logfile"

[string[]]$oldlogfilelist=""
get-item -path "$($PSScriptRoot)\logs.UpdateSqlDataMailProperties\NEXTCCC-UpdateSqlDataMailProperties.*.log" `
   | where {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | %{$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

####################################################################
# check if the stored procedure "sp_GetReorgDataStatus" is running #
####################################################################
#Import central functions module to load function "IsStoredProcedureRunning"
Import-Module "$($PSScriptRoot)\NEXTCCC-MailPropertiesFunctionsModule.psm1" -NoClobber -Verbose

[boolean]$reorgDataRunning = IsStoredProcedureRunning -SPName "sp_GetReorgDataStatus"
Write-Trace "reorgDataRunning is: $($reorgDataRunning)"
if($reorgDataRunning -eq $false)
{
    Write-Trace "Stored Procedure ReorgData is not running."
} elseif ($reorgDataRunning -eq $true) {
	Write-Trace "Stored Procedure ReorgData is running. Update will not be started. Exit."
	stop-transcript | out-null
	exit
}

###################################################################################
# check if the stored procedure "sp_GetUpdateMailPropertiesDataStatus" is running #
###################################################################################
#Import central functions module to load function "IsStoredProcedureRunning"
#Import-Module "$($PSScriptRoot)\NEXTCCC-MailPropertiesFunctionsModule.psm1" -NoClobber -Verbose

[boolean]$getUpdateMailPropertiesDataStatusRunning = IsStoredProcedureRunning -SPName "sp_GetUpdateMailPropertiesDataStatus"
Write-Trace "GetUpdateMailPropertiesDataStatusRunning is: $($getUpdateMailPropertiesDataStatusRunning)"
if($getUpdateMailPropertiesDataStatusRunning -eq $false)
{
    Write-Trace "Stored Procedure getUpdateMailPropertiesDataStatus is not running. Update will be started."
} elseif ($getUpdateMailPropertiesDataStatusRunning -eq $true) {
	Write-Trace "Stored Procedure getUpdateMailPropertiesDataStatus is running. Update will not be started. Exit."
	stop-transcript | out-null
	exit
}

################
# Main program #
################
$error.Clear()
Write-Trace "NEXTCCC-UpdateSqlDataMailProperties:Start"
$starttime = get-date

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Persist Security Info=False;Server=$($SQLServer);database=email_kpi;Integrated Security=true";
$SqlConnection.Open()
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = "sp_UpdateMailPropertiesData"
$SqlCmd.Connection = $SqlConnection
$sqlCmd.CommandType = [System.Data.CommandType]::StoredProcedure
$sqlCmd.CommandTimeout = 21600
$result = $sqlCmd.ExecuteNonQuery()
#if ($result -ne 0) {
#	$errorfound = $true
#}
$SqlConnection.Close()

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "NEXTCCC-UpdateSqlDataMailProperties:END"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0