﻿# NEXTCCC-MailProperties-Collect.ps1
#
# 20171026 JGD Initial Version
# 20171107  FC
#	Erweiterung um Autodiscover Adresse mit alternativem Einlesen.
#	Write-Trace Ausgaben
#	InternetmessageID addiert
#	Typisierung von Variablen
#	Errorbehandlung Autodiscover
#	Searchfilter auf letzte 24 Stunden
# 20171108 FC
#	MessageSubject entfernt
#	Disable 24h Filter
# 20171108 FC
#	Add $timeformat" for DateTie Formatting
# Requires Installed Managed EWS API dll
# 20171122 FC
#	DateTime in 24h format
#	FlagStartDateTime Behandlung 0001-01-01 12:00:00.000
# 20171127 JGD
#	changed JobID to match DateTime
# 20171207 FC
#	FlagStartDateTime Behandlung 0001-01-01 00:00:00.000
# 20180115 JGD 1.1
#	Added $global:mailCount to count processed mails for each mailbox and writing result in trace
#	Fixed string at the end to end instead of start
# 20180115 JGD 1.2
#	Fixed Issue with FolderId being to long if a space has been found in the name, maximum characters is always 5
#	Fixed issue with wrong mailcount handling
# 20180214 FC
#	AutoD Adresse ersetzt durch Get-Recipient
# 20180222 JGD
#	Added Flag $ignoreOutOfScopeMails which do not collect mails not with FolderID xx oder xx_yy if set to $true
# 20180223 JGD
#	Added flag $earliestReceivedDateTime. Only mails newer than this datetime are written to the database
# 20180301 FC umfangreiche änderungen
#	Erst auslesen der Ordnerliste und dann filter auf Ordnername
# 20210510 FC remove-PSSession addiert
# Optionen
#	Parallelisierung der Abfragen
# 20180528 AS Parallelisierung der Abfragen (Start-Job) -> Anzahl Exchange Server, auf denen die Mailboxen liegen = Anzahl paralleler Jobs;
#			Aufteilung der Log Dateien nach Job bzw. Server Bsp: NEXTCCC-MailProperties-Collect.trace.2018-05-28-10-34-41.comgtexmdb11.log
#			Auslagerung der Funktionen zum Abarbeiten von Mailboxen nach NEXTCCC-MailPropertiesFunctionsModule.psm1;
#			Generalisierung der Pfade für Log und Export Dateien (Vereinfachung für Dev)
#
# Zukunft: 
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),
	[string]$configcsv		  = "",
    [string]$ewsDllLoc        = "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll",
	[string]$exportcsvfile    = "",
	[string]$configFileName   = "NEXTCCC-MailProperties-ExportConfig.xml" ,
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[int]$donefilespurgedays  = 2,   # Purge csv files in done folder older than these days
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff",
	$ignoreOutOfScopeMails    = $true, #if set to true, only mails with FolderID xx and xx_yy are collected
	$earliestReceivedDateTime = "2018-01-01 00:00:00.001", # only take into account the mails, which are received after this date
	[string]$test="",     # Set to true to check Control-M Logic
	[string]$exchangeuri      = "https://outlook.miele.com/PowerShell/"
)

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')
[int]$global:mailCount = 0
##########################################################
# Helper Function to do tracing
##########################################################

Import-Module "$($PSScriptRoot)\write-trace.psm1"
set-TraceParameter `
   -tracefilename "$($PSScriptRoot)\logs.MailProperties-Collect\NEXTCCC-MailProperties-Collect.trace.$($jobidlog).log" `
   -levelfile 5 `
   -levelcon 5

#Get script location and use it as variable for file directories
$invocation = (Get-Variable MyInvocation).Value
$scriptdirectorypath = Split-Path $invocation.MyCommand.Path
Write-Trace "Script Directory Path: $scriptdirectorypath"

#Set config csv path
if ($configcsv -eq "") {
	Write-Trace "Parameter configcsv is not set"
	$configcsv = "$scriptdirectorypath\NEXTCCC-MailboxConfig.csv"
 }

#Set export csv file path
if ($exportcsvfile -eq "") {
   Write-Trace "Parameter exportcsvfile is not set"
   $exportcsvfile = "$scriptdirectorypath\ewscsv\NEXTCCC-MailProperties-Collect.$($jobidlog).csv"
}

Write-Trace "Collect-Mailproperties: Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "configcsv               : $($configcsv)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"
Write-Trace "Parameter exportcsvfile : $exportcsvfile"

##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#$objectRef = $host.GetType().GetField(“externalHostRef”, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetProperty”
#$consoleHost = $objectRef.GetType().GetProperty(“Value”, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(“IsStandardOutputRedirected”, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] “Instance,NonPublic,GetField”
#  $field = $consoleHost.GetType().GetField(“standardOutputWriter”, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(“standardErrorWriter”, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path "$scriptdirectorypath\logs.MailProperties-Collect")) {mkdir "$scriptdirectorypath\logs.MailProperties-Collect"}
[string]$transcriptfile = ("$scriptdirectorypath\logs.MailProperties-Collect\NEXTCCC-MailProperties-Collect.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace " Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

Write-Trace " Cleanup old Logfiles"
[string[]]$oldlogfilelist=""
get-item -path "$scriptdirectorypath\logs.MailProperties-Collect\NEXTCCC-MailProperties-Collect.*.log" `
	| Where-Object {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
	| ForEach-Object{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  Logfile $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old LogFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old LogFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old LogFile: $($oldlogfile)"
	}
}  

Write-Trace " Cleanup csv files in done folder"
[string[]]$oldlogfilelist=""
get-item -path "D:\Tasks\NEXTCCCReporting\ewscsv\done\*.csv" `
	| Where-Object {$_.lastwritetime -lt ((get-date).adddays(-$donefilespurgedays))} `
	| ForEach-Object{ 
		$oldlogfilelist+=$_.fullname
		Write-Trace "  CSVFile  $($_.fullname)"
	}
  
foreach ($oldlogfile in $oldlogfilelist) {
	if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "  Removing Old CSVFile: $($oldlogfile)"
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "  Skip not existing  Old CSVFile: $($oldlogfile)"
		}
	}
	else {
		Write-Trace "  Skip empty name of Old CSVFile: $($oldlogfile)"
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-MailProperties-Collect:Start"
$starttime = get-date

#########################################################
# Function MoveFiles to move files to another directory #
#########################################################
function MoveFiles($filesToMove, $sourceFileDirectory ,$destinationFileDirectory)
{
	if (!(test-path $destinationFileDirectory)) 
	{
		mkdir $destinationFileDirectory
	}

	foreach($fileName in $filesToMove)
	{
		$destinationFileName = $fileName.FullName.Replace($sourceFileDirectory, $destinationFileDirectory)
		if(Test-Path $destinationFileName)
		{
			Write-Trace "WARNING: Could not move file. The destination file already exists: $($destinationFileName)"
		}
		else
		{
			Write-Trace "Moving file $($fileName) to $($destinationFileDirectory)"
			Move-Item -Path $fileName.FullName -Destination $destinationFileName
		}
	}
}

#############################################
# Hauptprogramm
#############################################

Write-Trace "Collect-Mailproperties: Loading EWS_DLL"
Add-Type -Path $ewsDllLoc
#$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
Write-Trace " Create Exchange Service Object"
#$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)

# Import list of mailbox addresses from config csv file
Write-Trace "Loading Mailboxlist from $($configcsv) START"
[hashtable]$mailboxlist=@{}
## 03012021 RH : Check ob die CSV gelesen wurde auf wunsch von JGD eingefügt
try {
	$configcsvimport = Import-Csv -path $configcsv -ErrorAction Stop
	if($configcsvimport.active.count -gt 0) {
		Write-Trace "Loaded $($configcsvimport.active.count) Entrys"
	}
	else {
		Write-Trace "Exitcode:4 Could not load $(configcsv) correctly  - Check Logs"
		$error
		stop-transcript | out-null
		exit 4
	}
}
catch {
	Write-Trace "Exitcode:4 Could not load $(configcsv) correctly  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}
## 01032021 RH : Ende des Changes
foreach ($entry in ($configcsvimport | Where-Object {$_.active -eq "1"} )) {
	$mailboxlist.($entry.MailboxSMTP) = $entry.MailboxSMTP
}

#Create empty array to save hashtable for each server. In each hashtable all mailboxes will be listed which belongs to the corresponding server
$arrayServerMailboxes = @()
#Create empty array to collect all failed mailboxes
$failedMailboxes = @()

##########################################################
# Loading Exchange environment
##########################################################
#[string]$exchangeuri      = "https://outlook.miele.com/PowerShell/"
Write-Trace "Loading Exchange Environment"
Write-Trace "Creating Exchange Remote Session to $($exchangeuri)"

#Alt. not supportet https://blog.rmilne.ca/2015/01/28/directly-loading-exchange-2010-or-2013-snapin-is-not-supported/
#Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010

$session = new-pssession `
	-ConfigurationName "Microsoft.Exchange" `
	-ConnectionUri $exchangeuri `
	-Authentication negotiate
Write-Trace "VGDReport:inf0: Import Exchange Remote Session Commandlets"
import-pssession -Session $session -AllowClobber | out-null

if ($error) {
	Write-Trace "Exitcode:8 Unable to load Exchange Snapins"
	$error 
	$error  | export-clixml ("$($PSScriptRoot)\logs.tracking-Collect\NEXTCCC-tracking-Collect.error."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
	exit 8
}


#iterate through all mailboxes
foreach ($mailbox in $mailboxlist.keys){
	
	Write-Trace "Try to load mailbox $mailbox"
	#try to get mailbox
	$currentMB = Get-Mailbox -Identity $mailbox -erroraction SilentlyContinue
	#if mailbox could not be loaded, write log and continue with next mailbox
	if($null -eq $currentMB)
	{
		$failedMailboxes+= $mailbox
		Write-Trace "ERROR: Could not get mailbox $mailbox. Continue with next one."		
		continue
	}	
	
	#get server where the mailbox is located on
	$currentMBServer = $currentMB.Servername
	#if $arrayServerMailboxes is not empty and contains object with current server name, then add mailbox to hashtable in this object
	if($arrayServerMailboxes.Count -ne 0 -and ($arrayServerMailboxes.Name.Contains($currentMBServer)))
	{
		#get index of array object
		$arrayObj = $arrayServerMailboxes | Where-Object {$_.Name -eq $currentMBServer}
		$arrayObjIndex = $arrayServerMailboxes.IndexOf($arrayObj)
		#add mailbox to hashtable in this object
		$arrayServerMailboxes[$arrayObjIndex].values += $mailbox

	} else {		
		#if $arrayServerMailboxes is empty or does not contains object with current server name, then add current server obj to array and mailbox to hashtable of new object
		$arrayServerMailboxes += @{ name = $currentMBServer; values = @($mailbox) }
	}	
}

#List all mailboxes which could not be loaded
if($failedMailboxes.count -gt 0)
{
	$failedMailboxes = ($failedMailboxes -join ", ").ToString()
	Write-Trace "WARNING: Mailboxes could not be loaded: $failedMailboxes"
}

#get number of objects in $arrayServerMailboxes
$numberOfServerMailBoxesObjects = $arrayServerMailboxes.Count
Write-Trace "INFO: Number of arrayServerMailboxes objects: $numberOfServerMailBoxesObjects" 
#list $arrayServerMailboxes contents
Write-Trace "INFO: ArrayServerMailboxes:"
$arrayServerMailboxes

[int]$jobCounter = 0
#iterate through all $arrayServerMailboxes objects and process them
while ($jobCounter -lt $numberOfServerMailBoxesObjects)
{	
    $currentServer = $arrayServerMailboxes[$jobCounter]
	$jobname = "Job$jobCounter"
	#start new Job for current $arrayServerMailboxes object
    Start-Job -Name $jobname -ArgumentList @($currentServer, $jobid, $jobidlog, $scriptdirectorypath) -ScriptBlock {
		param ($currentServer, $jobid, $jobidlog, $scriptdirectorypath) 
		$currServerName = $currentServer.name
		Start-Transcript -Path "$scriptdirectorypath\logs.MailProperties-Collect\NEXTCCC-MailProperties-Collect.trace.$($jobidlog).$($currServerName).log"		
		Import-Module $scriptdirectorypath\write-trace.psm1
		Import-Module $scriptdirectorypath\NEXTCCC-MailPropertiesFunctionsModule.psm1
		Write-Trace "Performing server:  $currServerName"
		$exportcsvfile = "$scriptdirectorypath\ewscsv\NEXTCCC-MailProperties-Collect.$($jobidlog).$($currServerName).csv"		
		
		[int]$mailboxcount=0

		$( foreach ($mailbox in $currentServer.Values){				
			Write-Trace -Level 4 "Collect mails from Mailbox $($mailbox)"
		Write-Trace -Level 4 "    AutodAddress= $($mailbox)"
			$mailboxcount++			
			Process-Mailbox($mailbox)    
		}) `
		| export-csv `
			-path $exportcsvfile `
			-encoding unicode `
			-notypeinformation

		Stop-Transcript
    } 
	$jobCounter++
	
}

While (Get-Job -State "Running") {
	Clear-Host
	get-date -format "yyyy-MM-dd HH:mm:ss"
    Get-Job | Format-Table Id, Name, State
    Start-Sleep 60 
}
Clear-Host
Get-Job | Format-Table Id, Name, State, PSBeginTime, PSEndTime
write-host "Jobs completed"

Remove-Job *

$sourceFD =  "$scriptdirectorypath\ewscsv"
#$destinationFD = "$scriptdirectorypath\ewscsv\export"

#Load configuration file
#$configFileName   = "NEXTCCC-MailProperties-ExportConfig.xml"
try{
	Write-Trace "Loading configuration file: $($configFileName)" 
	$configFilePath = "$($PSScriptRoot)\$($configFileName)"
	[xml]$configurationFile = Get-Content $configFilePath
	Write-Trace "Configuration file loaded successfully."
	#get export files directory
	$destinationFD = $configurationFile.Settings.ExportFilesDirectory
}
catch [System.FileNotFoundException]
{
	LogHelper.WriteLogError("Could no load configuration file: $($configFileName) | (File not found)");
	Write-Trace "Using local export files directory"
	$destinationFD = "$scriptdirectorypath\ewscsv\export" 
}

$files=@(get-childitem -path $sourceFD -File -Filter "*.csv")
Write-Trace "Moving files from $($sourceFD) to $($destinationFD)"
MoveFiles -filesToMove $files -sourceFileDirectory $sourceFD -destinationFileDirectory $destinationFD

Write-Trace "Totaltime $(((get-date) - $starttime))"

Write-Trace "remove Exchange Session"
Remove-pssession $session 

Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:0 Warnings during run  - Check Logs" 
	$error
	stop-transcript | out-null
	exit 0 #01.03.2021 RH : auf wunsch von JGD von 4 auf 0 umgestellt
}

stop-transcript| out-null
exit 0
Write-Trace "Collect-Mailproperties: End"