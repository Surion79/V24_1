# NEXTCCC-tracking-Collect.ps1
#
# Collects the last full hour of messages from all exchange message tracking logs and stores it in a CSV-File
#  if started ca 11:05am  the file will contain 10:00am-11:00am logs
#
# 20171019 FC Initial Version
# 20171109 FC Anpassung DateTime Format ausgabe mit [string]$timeformat = "yyyy-MM-dd hh:mm:ss.fff"
# 20171122 FC 
#	Anpassung DateTime Format ausgabe mit [string]$timeformat = "yyyy-MM-dd HH:mm:ss.fff"
#	Umstellung Transportserver Ermittlung ohne Edge Rolle
# 20171127 JGD
#	Changed JobId String to match a possible datetime format.
# Requires local Exchange PowerShell Snapins
# 20180214 FC  Ausgehend auf STOREDRIVER/RECEIVE.
#			FC Cleanup der CSV_Dateien nach 7 Tagen aktiviert
#
# 20180222 JGD added parameter useAgentInfo to use AGENTINFO for receive/send
# 20180517 JGD changed Recipents to original mailbox only, so aliases do not create issues/missing entries in post processing in SQL
# 20210505 FC  Umstellung auf Remote PowerShell
# 20210506 FC  Added "Remove-PSession" to free up Exchange PowerShell sesssion

# Optionen
#	Parallelisierung der Abfragen
#	InvokeCommand mit Remote Powershell um Tracking "lokal" zu filtern
#
# Sample to get logs from day 30 
#  1..29 | %{.\Collect-nextccmtracking.ps1 -starttimestamp (get-date).adddays(-($_)) -endtimestamp (get-date).adddays(-($_ -1)) -exportcsvfile "C:\Tasks\NEXTCCCReporting\trackingcsv\NEXTCCC-tracking-Collect.$($_).csv"}

# pending
#  CSV File anbd Start/End Date name conflict solve  for historical data
#
# https://blogs.technet.microsoft.com/heyscriptingguy/2011/11/28/four-easy-ways-to-import-csv-files-to-sql-server-with-powershell/
# https://gallery.technet.microsoft.com/ScriptCenter/7985b7ef-ed89-4dfd-b02a-433cc4e30894/

[CMDLetBinding()]
param (
	[string]$jobid            = (get-date -format "yyyy-MM-dd HH:mm:ss"),
	[string]$configcsv        = "C:\Tasks\NEXTCCCReporting\NEXTCCC-MailboxConfig.csv",
	$starttimestamp           = (get-date (get-date).addhours(-2) -format "MM/dd/yyyy HH:00:00"),   # start of this day
	$endtimestamp             = (get-date -format "MM/dd/yyyy HH:00:00"),   # 
    $exportcsvfile            = $null,   # name will be calculated in the code if no filename was specified
	[string]$timeformat       = "yyyy-MM-dd HH:mm:ss.fff",  
	[int]$transcriptpurgedays = 7,   # Purge log files older than these days
	[string]$test             = "",     # Set to true to check Control-M Logic
	$useAgentInfo             = $true,
	[int]$maxLengthString  	  = 190,
	#[string]$exchangeuri      = "http://COMGTEXMDB15.com.miele.net/PowerShell/"
	[string]$exchangeuri      = "https://outlook.miele.com/PowerShell/"
)

set-psdebug -strict
$error.clear()

[string]$jobidlog = $jobid.replace(':', '-').replace(' ', '-')

##########################################################
# Helper Function to do tracing
##########################################################

Import-Module "$($PSScriptRoot)\write-trace.psm1"
set-TraceParameter `
	-tracefilename "$($PSScriptRoot)\logs.tracking-Collect\NEXTCCC-tracking-Collect.trace.$($jobidlog).log" `
	-levelfile 5 `
	-levelcon 5

Write-Trace "Start"
Write-Trace "Scriptname              : $($MyInvocation.InvocationName)"
Write-Trace "JobID                   : $($jobid)"
Write-Trace "JobIdLog                : $($jobidlog)"
Write-Trace "Servername              : $($env:COMPUTERNAME)"
Write-Trace "Username                : $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Trace "Parameter exportcsvfile : $exportcsvfile"
Write-Trace "Parameter starttimestamp: $starttimestamp"
Write-Trace "Parameter endtimestamp  : $endtimestamp"
Write-Trace "Parameter timeformat    : $timeformat"
Write-Trace "Tracefile               : $((get-traceparameter).tracefilename)"


##########################################################
# Required Code for Control-M
##########################################################
# See http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/ for details
#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#$objectRef = $host.GetType().GetField(�externalHostRef�, $bindingFlags).GetValue($host)

#$bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetProperty�
#$consoleHost = $objectRef.GetType().GetProperty(�Value�, $bindingFlags).GetValue($objectRef, @())

# Add console object type check
#if ( $consoleHost.GetType().FullName -eq "Microsoft.PowerShell.ConsoleHost" ) 
#{
#  [void] $consoleHost.GetType().GetProperty(�IsStandardOutputRedirected�, $bindingFlags).GetValue($consoleHost, @())
#  $bindingFlags = [Reflection.BindingFlags] �Instance,NonPublic,GetField�
#  $field = $consoleHost.GetType().GetField(�standardOutputWriter�, $bindingFlags)
#  $field.SetValue($consoleHost, [Console]::Out)
#  $field2 = $consoleHost.GetType().GetField(�standardErrorWriter�, $bindingFlags)
#  $field2.SetValue($consoleHost, [Console]::Out)
#}

##########################################################
# Enable Transcript an cleanup older files
##########################################################
if (!(test-path "$($PSScriptRoot)\logs.tracking-Collect")) {mkdir "$($PSScriptRoot)\logs.tracking-Collect"}
[string]$transcriptfile = ("$($PSScriptRoot)\logs.tracking-Collect\NEXTCCC-tracking-Collect.transcript."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
Write-Trace "Start Transcript to $($transcriptfile)"
Start-Transcript -path $transcriptfile | out-null

[string[]]$oldlogfilelist=""
get-item -path "$($PSScriptRoot)\logs.tracking-Collect\NEXTCCC-tracking-Collect.*.log" `
   | where-object {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | ForEach-Object {$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old LogFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old LogFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old LogFile: $($oldlogfile)" 3
	}
}  

[string[]]$oldlogfilelist=""
get-item -path "$($PSScriptRoot)\trackingcsv\done\NEXTCCC-tracking-Collect.*.csv" `
   | Where-Object {$_.lastwritetime -lt ((get-date).adddays(-$transcriptpurgedays))} `
   | ForEach-Object {$oldlogfilelist+=$_.fullname}
foreach ($oldlogfile in $oldlogfilelist) {
    if ($oldlogfile) { # only if oldlogpath is not null or empty
		if (test-path $oldlogfile) {
			Write-Trace "Removing Old CSVFile: $($oldlogfile)" 3
			remove-item -path $oldlogfile
		}
		else {
			Write-Trace "Skip not existing  Old CSVFile: $($oldlogfile)" 3
		}
    }
	else {
		Write-Trace "Skip empty name of Old CSVFile: $($oldlogfile)" 3
	}
}  

##########################################################
# Control-M Test Mode
##########################################################
if ($test -ne "") {
	Write-Trace "Control_M TestMode found. Exitcode:$test"
	stop-transcript | out-null
	exit ([int]$test)
}

Write-Trace "NEXTCCC-tracking-Collect:Start"
$starttime = get-date

##########################################################
# Loading Exchange environment
##########################################################
Write-Trace "Loading Exchange Environment"
Write-Trace "Creating Exchange Remote Session to $($exchangeuri)"

#Alt. not supportet https://blog.rmilne.ca/2015/01/28/directly-loading-exchange-2010-or-2013-snapin-is-not-supported/
#Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010

$session = new-pssession `
	-ConfigurationName "Microsoft.Exchange" `
	-ConnectionUri $exchangeuri `
	-Authentication negotiate
Write-Trace "VGDReport:inf0: Import Exchange Remote Session Commandlets"
import-pssession -Session $session -AllowClobber | out-null

if ($error) {
	Write-Trace "Exitcode:8 Unable to load Exchange Snapins"
	$error 
	$error  | export-clixml ("$($PSScriptRoot)\logs.tracking-Collect\NEXTCCC-tracking-Collect.error."+(get-date -format "yyyy-MM-dd-HH-mm-ss-fff")+".log")
	exit 8
}

Write-Trace "Generating Exportrcsv Filename Start"
if ($null -eq $exportcsvfile) {
	$exportcsvfile = "$($PSScriptRoot)\trackingcsv\NEXTCCC-tracking-Collect.$(get-date (get-date).addhours(-1) -format "yyyyMMddHH00").csv"
	Write-Trace "Using calculated File: $exportcsvfile"
}
else {
	Write-Trace "Using given File: $exportcsvfile"
}
Write-Trace "Generating Exportrcsv Filename End"

Write-Trace "Set Scope to EntireForest"
#Set-AdServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue -PreferredGlobalCatalog $MsxGcDC
Set-ADServerSettings -ViewEntireForest $true

Write-Trace "Loading Transportservices Start"
#$transportservices = Get-TransportService    # liefert auch die Edge Server

$transportservices = Get-ExchangeServer | Where-Object {$_.IsHubTransportServer -or $_.IsFrontendTransportServer}

if (!$transportservices) {
	write-error "Unable to load transport services list."
	exit 1
}


$transportservices |`
    ForEach-Object{`
	   Write-Trace "Transportservice $($_.name)" -Level 4
	}
Write-Trace "Loading Transportservices Done. Total Services:$($transportservices.count)"


Write-Trace "Loading Mailboxlist from $($configcsv) START"
[hashtable]$mailboxlist=@{}
foreach ($entry in (Import-Csv -path $configcsv | Where-Object {$_.active -eq "1"} )) {
	$mailboxlist.($entry.MailboxSMTP) = $entry.MailboxSMTP
	Write-Trace " Mailbox $($entry.MailboxSMTP)"
}
Write-Trace "Loading Mailboxlist from $($configcsv) STOP  Total:$($mailboxlist.count)"
$mailboxlist `
	| ForEach-Object {Write-Trace -Level 3 "Mailbox: $($_)"  }

$mailboxcount=0
# Foreach endet daten nicht direkt in die Pipeline. Fehler An empty pipe element is not allowed. daher gesonderte Klammern  
$( foreach ($mailbox in $mailboxlist.keys){
    Write-Trace -Level 4 "Tracking for Mailbox $($mailbox)"
    $mailboxcount++
    Write-Progress `
        -Id 1 `
        -Activity "Mailboxcount $($mailboxcount) of $($mailboxlist.count)" `
		-Status "Mailbox $mailbox" `
        -PercentComplete ($mailboxcount / $mailboxlist.count *100)
    $transportcount =0
    foreach ($transportservice in $transportservices){
        $transportcount ++
        Write-Trace  -Level 5 "Loading Messagetracking from Server $($transportservice.name)"
        Write-Progress `
            -Id 2 `
            -Activity "Transportcount $($transportcount) of $($transportservices.count)" `
			-Status "Transportservice $transportservice" `
            -PercentComplete ($transportcount / $transportservices.count *100)
		if ($useAgentInfo) {
			Write-Trace -Level 5 "Processing DELIVER-Messages"
			Get-MessageTrackingLog `
				-Server $transportservice.name `
				-Recipients $mailbox `
				-Start $starttimestamp `
				-End   $endtimestamp `
				-EventId AGENTINFO `
				-Resultsize unlimited `
			| Select-Object 	@{name="JobID";expression={$jobid}},`
						@{name="Direction";expression={"IN"}},`
						MessageId,`
						@{name="MessageSubject";expression={if(($_.MessageSubject).Length -gt $maxLengthString){($_.MessageSubject).Substring(0,$maxLengthString)}else{($_.MessageSubject)}}},`
						NetworkMessageId,`Sender,`
						@{name="Recipients";expression={$mailbox}},`
						@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
						TotalBytes
						
			Write-Trace  -Level 5 "Processing SUBMIT-Messages"
			Get-MessageTrackingLog `
				-Server $transportservice.name `
				-Sender $mailbox `
				-Start $starttimestamp `
				-End   $endtimestamp `
				-EventId AGENTINFO `
				-Resultsize unlimited `
			| Select-Object 	@{Name="JobID";Expression={$jobid}},`
						@{name="Direction";expression={"OUT"}},`
						MessageId,`
						@{name="MessageSubject";expression={if(($_.MessageSubject).Length -gt $maxLengthString){($_.MessageSubject).Substring(0,$maxLengthString)}else{($_.MessageSubject)}}},`
						NetworkMessageId,`
						@{Name="Sender";Expression={$mailbox}},`
						@{name="Recipients";expression={if(($_.Recipients -join ";").Length -gt $maxLengthString){($_.Recipients -join ";").Substring(0,$maxLengthString)}else{($_.Recipients -join ";")}}},`
						@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
						TotalBytes
		} 
		else {
			Write-Trace  -Level 5 "Processing Messages to local mailbox  STOREDRIVER/DELIVER"
			Get-MessageTrackingLog `
				-Server $transportservice.name `
				-Recipients $mailbox `
				-Start $starttimestamp `
				-End   $endtimestamp `
				-EventId DELIVER `
				-Source STOREDRIVER `
				-Resultsize unlimited `
			| Select-Object 	@{name="JobID";expression={$jobid}},`
								@{name="Direction";expression={"IN"}},`
								MessageId,`
								@{name="MessageSubject";expression={if(($_.MessageSubject).Length -gt $maxLengthString){($_.MessageSubject).Substring(0,$maxLengthString)}else{($_.MessageSubject)}}},`
								NetworkMessageId,Sender,`
								@{name="Recipients";expression={$mailbox}},`
								@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
								TotalBytes

			Write-Trace  -Level 5 "Processing Messages from local mailbox  STOREDRIVER/RECEIVE"
			Get-MessageTrackingLog `
				-Server $transportservice.name `
				-Sender $mailbox `
				-Start $starttimestamp `
				-End   $endtimestamp `
				-Source STOREDRIVER `
				-EventId RECEIVE `
				-Resultsize unlimited `
			| Select-Object 	@{Name="JobID";Expression={$jobid}},`
								@{name="Direction";expression={"OUT"}},`
								MessageId,`
								@{name="MessageSubject";expression={if(($_.MessageSubject).Length -gt $maxLengthString){($_.MessageSubject).Substring(0,$maxLengthString)}else{($_.MessageSubject)}}},`
								NetworkMessageId,Sender,`
								@{name="Recipients";expression={if(($_.Recipients -join ";").Length -gt $maxLengthString){($_.Recipients -join ";").Substring(0,$maxLengthString)}else{($_.Recipients -join ";")}}},`
								@{name="Timestamp";expression={$_.Timestamp.tostring($timeformat)}},`
								TotalBytes
		}
		Write-Trace  -Level 3 "Loading Messagetracking from Server $($transportservice.name) DONE"
    }
}) `
| export-csv `
	-path $exportcsvfile `
	-encoding unicode `
	-notypeinformation

Write-Trace "Results written to $exportcsvfile "

Write-Trace "Remove PSSession"
Remove-PSSession $session

Write-Trace "Totaltime $(((get-date) - $starttime))"
Write-Trace "End"

##########################################################
# Closing
##########################################################
if ($error) {
	Write-Trace "Exitcode:4 Warnings during run  - Check Logs"
	$error
	stop-transcript | out-null
	exit 4
}

stop-transcript| out-null
exit 0